<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\RunEncryptedBackupJob;
use App\Models\BackupRun;
use Illuminate\Http\Request;

class BackupController extends Controller
{
    public function index(Request $request)
    {
        $runs = BackupRun::query()
            ->latest('id')
            ->paginate(min(max($request->integer('per_page', 25), 1), 100));

        $runs->getCollection()->transform(fn (BackupRun $run) => [
            'id' => $run->id,
            'status' => $run->status,
            'disk' => $run->disk,
            'path' => $run->path,
            'bytes' => $run->bytes,
            'sha256' => $run->sha256,
            'started_at' => $run->started_at,
            'completed_at' => $run->completed_at,
            'failure_message' => $run->status === 'failed' ? $run->failure_message : null,
        ]);

        return response()->json($runs);
    }

    public function store()
    {
        RunEncryptedBackupJob::dispatch()->onQueue('backups');

        return response()->json([
            'message' => 'Encrypted backup request queued. Refresh the backup list for the result.',
        ], 202);
    }
}
