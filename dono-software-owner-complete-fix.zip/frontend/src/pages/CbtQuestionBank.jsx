import { useEffect, useState } from "react";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";
import { getPrimaryRoleSlug } from "../utils/role";
import PageContainer from "../components/layout/PageContainer";
import PageHeader from "../components/layout/PageHeader";
import LoadingSpinner from "../components/feedback/LoadingSpinner";
import EmptyState from "../components/feedback/EmptyState";

const initial = { question: "", options: ["", "", "", ""], correct_answer: "", marks: 1, examination_id: "", is_active: true };
const normalize = (response) => {
  const value = response?.data?.data ?? response?.data ?? [];
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  return [];
};

export default function CbtQuestionBank() {
  const { roles, isPlatformAdmin, isOrganizationOwner, school } = useAuth();
  const role = getPrimaryRoleSlug({ roles, isPlatformAdmin, isOrganizationOwner, school });
  const canManage = ["proprietor", "principal", "vice_principal_academic", "primary_headmaster", "secondary_principal", "teacher"].includes(role);
  const [items, setItems] = useState([]);
  const [form, setForm] = useState(initial);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    try {
      setLoading(true);
      setError("");
      const response = await api.get(role === "student" ? "/student/cbt-questions" : "/cbt-questions");
      setItems(normalize(response));
    } catch (err) {
      setItems([]);
      setError(err.response?.data?.message || "Unable to load CBT questions.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [role]);

  async function submit(event) {
    event.preventDefault();
    try {
      setSaving(true);
      setError("");
      await api.post("/cbt-questions", { ...form, options: form.options.filter(Boolean), marks: Number(form.marks), examination_id: form.examination_id ? Number(form.examination_id) : null });
      setForm(initial);
      setShowForm(false);
      setMessage("Question added to the CBT bank.");
      await load();
    } catch (err) {
      const errors = err.response?.data?.errors;
      setError(errors ? Object.values(errors)?.[0]?.[0] : err.response?.data?.message || "Unable to save question.");
    } finally {
      setSaving(false);
    }
  }

  return <PageContainer>
    <PageHeader title="Question Bank (CBT)" subtitle="Create and review school-scoped computer-based test questions." action={canManage ? <button type="button" onClick={() => setShowForm((value) => !value)} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">{showForm ? "Close" : "Add question"}</button> : null} />
    {error && <div role="alert" className="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error} <button type="button" onClick={load} className="ml-2 underline">Retry</button></div>}
    {message && <div role="status" className="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">{message}</div>}
    {showForm && canManage && <form onSubmit={submit} className="mb-6 space-y-4 rounded-xl border bg-white p-4 shadow-sm"><label className="block text-sm font-semibold">Question<textarea required value={form.question} onChange={(event) => setForm({ ...form, question: event.target.value })} className="mt-1 min-h-24 w-full rounded-lg border p-2 font-normal" /></label><div className="grid gap-3 sm:grid-cols-2">{form.options.map((option, index) => <input key={index} required value={option} placeholder={`Option ${index + 1}`} onChange={(event) => setForm({ ...form, options: form.options.map((entry, entryIndex) => entryIndex === index ? event.target.value : entry) })} className="rounded-lg border p-2" />)}</div><div className="grid gap-3 sm:grid-cols-2"><input required placeholder="Correct answer (exact option text)" value={form.correct_answer} onChange={(event) => setForm({ ...form, correct_answer: event.target.value })} className="rounded-lg border p-2" /><input type="number" min="1" value={form.marks} onChange={(event) => setForm({ ...form, marks: event.target.value })} className="rounded-lg border p-2" /></div><button disabled={saving} className="rounded-lg bg-indigo-600 px-4 py-2 font-semibold text-white disabled:opacity-60">{saving ? "Saving..." : "Save question"}</button></form>}
    {loading ? <LoadingSpinner /> : items.length === 0 ? <EmptyState title="No CBT questions" message="Create the first question for this school." /> : <div className="space-y-3">{items.map((item) => <article key={item.id} className="rounded-xl border bg-white p-4 shadow-sm"><p className="font-semibold text-slate-900">{item.question}</p><ol className="mt-2 list-decimal pl-5 text-sm text-slate-600">{(Array.isArray(item.options) ? item.options : []).map((option, index) => <li key={index}>{option}</li>)}</ol><p className="mt-2 text-xs text-slate-500">Marks: {item.marks ?? 1}{item.examination?.name ? ` · ${item.examination.name}` : ""}</p></article>)}</div>}
  </PageContainer>;
}
