<?php

namespace App\Services\Academic;

use App\Models\Attendance;
use App\Models\ParentModel;
use App\Models\Result;
use App\Models\StudentEnrollment;
use App\Models\StudentResultSummary;
use App\Services\Academic\ResultProcessingService;
use Barryvdh\DomPDF\Facade\Pdf;

class ReportCardService
{
    public function __construct(
        protected ResultProcessingService $processingService
    ) {}

    /**
     * Generate complete report card payload for a student enrollment.
     */
    public function generatePayload(
        StudentEnrollment $enrollment,
        int $academicSessionId,
        int $termId
    ): array {
        $schoolId = $enrollment->school_id;

        // Fetch subject results for the term
        $subjectResults = Result::with([
            'subject',
            'components.assessmentStructure',
        ])
        ->where('school_id', $schoolId)
        ->where('student_enrollment_id', $enrollment->id)
        ->where('academic_session_id', $academicSessionId)
        ->where('term_id', $termId)
        ->orderBy('subject_id')
        ->get();

        // Retrieve or calculate result summary
        $summary = StudentResultSummary::where('school_id', $schoolId)
            ->where('student_enrollment_id', $enrollment->id)
            ->where('academic_session_id', $academicSessionId)
            ->where('term_id', $termId)
            ->first();

        if (! $summary && $subjectResults->isNotEmpty()) {
            $this->processingService->rebuildStudentSummary($enrollment->id, $academicSessionId, $termId);
            $summary = StudentResultSummary::query()
                ->where('school_id', $schoolId)
                ->where('student_enrollment_id', $enrollment->id)
                ->where('academic_session_id', $academicSessionId)
                ->where('term_id', $termId)
                ->first();
        }

        /* Attendance Metrics */
        $attendance = Attendance::where('student_enrollment_id', $enrollment->id)
            ->where('academic_session_id', $academicSessionId)
            ->where('term_id', $termId)
            ->get();

        $daysPresent = $attendance->where('status', 'Present')->count();
        $daysAbsent = $attendance->where('status', 'Absent')->count();
        $daysLate = $attendance->where('status', 'Late')->count();
        $daysExcused = $attendance->where('status', 'Excused')->count();
        $daysOpened = $attendance->count();

        $attendancePercentage = $daysOpened > 0
            ? round(($daysPresent / $daysOpened) * 100, 2)
            : 0;

        /* Linked Parent Information */
        $parent = ParentModel::whereHas('students', function ($query) use ($enrollment) {
            $query->where('students.id', $enrollment->student_id);
        })->first();

        return [
            'student' => $enrollment->load(['student', 'class', 'stream', 'school']),
            'parent' => $parent,
            'summary' => $summary,
            'subject_results' => $subjectResults,
            'attendance' => [
                'days_present' => $daysPresent,
                'days_absent' => $daysAbsent,
                'days_late' => $daysLate,
                'days_excused' => $daysExcused,
                'days_opened' => $daysOpened,
                'attendance_percentage' => $attendancePercentage,
            ],
            'generated_at' => now()->toDateTimeString(),
        ];
    }

    /**
     * Download or stream the PDF Report Card.
     */
    public function downloadPdf(
        StudentEnrollment $enrollment,
        int $academicSessionId,
        int $termId,
        string $viewName = 'pdf.report-card'
    ) {
        $payload = $this->generatePayload($enrollment, $academicSessionId, $termId);

        $pdf = Pdf::loadView($viewName, $payload)
            ->setPaper('a4', 'portrait');

        $fileName = sprintf(
            'ReportCard_%s_%s.pdf',
            str_replace(' ', '_', $payload['student']->student->full_name ?? 'Student'),
            now()->format('Y_m_d')
        );

        return $pdf->download($fileName);
    }
}
