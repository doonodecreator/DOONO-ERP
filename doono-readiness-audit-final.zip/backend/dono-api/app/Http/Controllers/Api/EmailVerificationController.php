<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\EmailVerificationService;
use Illuminate\Http\Request;

class EmailVerificationController extends Controller
{
    public function __construct(private EmailVerificationService $verification) {}

    public function verify(Request $request, int $id, string $hash)
    {
        abort_unless($request->hasValidSignature(), 403, 'This verification link is invalid or expired.');
        $user = User::findOrFail($id);
        abort_unless(hash_equals($hash, sha1($user->getEmailForVerification())), 403, 'This verification link is invalid.');

        if (! $user->hasVerifiedEmail()) {
            $user->markEmailAsVerified();
        }

        $frontendUrl = rtrim((string) env('FRONTEND_URL', config('app.url')), '/');
        return redirect()->away($frontendUrl.'/email-verified?verified=1');
    }

    public function resend(Request $request)
    {
        $data = $request->validate(['email' => ['required', 'email']]);
        $email = strtolower(trim($data['email']));
        $user = User::where('email', $email)->first();

        if ($user && ! $user->hasVerifiedEmail()) {
            $this->verification->send($user);
        }

        return response()->json([
            'message' => 'If an account exists with that email and it is not verified, a new verification link has been sent.',
        ], 202);
    }
}
