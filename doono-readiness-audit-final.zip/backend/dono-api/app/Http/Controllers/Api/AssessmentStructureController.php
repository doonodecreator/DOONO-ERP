<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreAssessmentStructureRequest;
use App\Http\Requests\UpdateAssessmentStructureRequest;
use App\Http\Resources\AssessmentStructureResource;
use App\Models\AssessmentStructure;
use Illuminate\Http\Request;

class AssessmentStructureController extends Controller
{
    /**
     * Display a listing.
     */
    public function index(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        return AssessmentStructureResource::collection(
            AssessmentStructure::where('school_id', $schoolId)
                ->with('school')
                ->orderBy('display_order')
                ->paginate(100)
        );
    }

    /**
     * Store.
     */
    public function store(StoreAssessmentStructureRequest $request)
    {
        $data = $request->validated();
        $data['school_id'] = $this->requireSchool($request);
        $structure = AssessmentStructure::create($data);

        return (new AssessmentStructureResource(
            $structure->load('school')
        ))
        ->response()
        ->setStatusCode(201);
    }

    /**
     * Show.
     */
    public function show(Request $request, AssessmentStructure $assessmentStructure)
    {
        abort_unless((int) $assessmentStructure->school_id === $this->requireSchool($request), 404);
        return new AssessmentStructureResource($assessmentStructure->load('school'));
    }

    /**
     * Update.
     */
    public function update(
        UpdateAssessmentStructureRequest $request,
        AssessmentStructure $assessmentStructure
    ) {
        abort_unless((int) $assessmentStructure->school_id === $this->requireSchool($request), 404);
        $data = $request->validated();
        unset($data['school_id']);
        $assessmentStructure->update($data);

        return new AssessmentStructureResource(
            $assessmentStructure->load('school')
        );
    }

    /**
     * Delete.
     */
    public function destroy(Request $request, AssessmentStructure $assessmentStructure)
    {
        abort_unless((int) $assessmentStructure->school_id === $this->requireSchool($request), 404);
        $assessmentStructure->delete();

        return response()->json([
            'message' =>
                'Assessment structure deleted successfully.'
        ]);
    }
}
