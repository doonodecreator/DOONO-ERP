<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('schools', function (Blueprint $table) {

            $table->foreignId('owner_id')
                ->nullable()
                ->after('organization_id')
                ->constrained('users')
                ->nullOnDelete();

        });
    }

    public function down(): void
    {
        Schema::table('schools', function (Blueprint $table) {

            $table->dropForeign(['owner_id']);
            $table->dropColumn('owner_id');

        });
    }
};
