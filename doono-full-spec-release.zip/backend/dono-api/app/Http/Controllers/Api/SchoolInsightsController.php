<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Attendance;
use App\Models\Result;
use App\Models\Student;
use App\Services\CurrentContextService;
use Illuminate\Http\Request;

class SchoolInsightsController extends Controller
{
    public function __construct(private CurrentContextService $context) {}

    public function index(Request $request)
    {
        $user = $request->user();
        $school = $this->context->currentSchool($user);
        abort_unless($school, 403, 'Select a school before opening insights.');

        $from = now()->subDays(min(max($request->integer('days', 30), 7), 365))->startOfDay();
        $schoolId = (int) $school->id;

        $attendance = Attendance::query()
            ->whereHas('studentEnrollment', fn ($query) => $query->where('school_id', $schoolId))
            ->whereDate('attendance_date', '>=', $from->toDateString())
            ->get(['status', 'attendance_date']);

        $attendanceTotal = $attendance->count();
        $attendancePresent = $attendance->whereIn('status', ['Present', 'Late'])->count();
        $attendancePercentage = $attendanceTotal > 0
            ? round(($attendancePresent / $attendanceTotal) * 100, 1)
            : null;

        $publishedResults = Result::query()
            ->where('school_id', $schoolId)
            ->where('is_published', true)
            ->whereNotNull('total_score')
            ->with(['subject:id,name'])
            ->get(['subject_id', 'total_score']);

        $averageScore = $publishedResults->count() > 0
            ? round((float) $publishedResults->avg('total_score'), 1)
            : null;

        $subjectAverages = $publishedResults
            ->groupBy('subject_id')
            ->map(function ($rows) {
                return [
                    'subject' => $rows->first()->subject?->name ?: 'Unknown subject',
                    'average_score' => round((float) $rows->avg('total_score'), 1),
                    'result_count' => $rows->count(),
                ];
            })
            ->values()
            ->sortBy('average_score')
            ->values()
            ->all();

        $warnings = [];
        if ($attendancePercentage !== null && $attendancePercentage < 80) {
            $warnings[] = [
                'severity' => $attendancePercentage < 70 ? 'high' : 'medium',
                'type' => 'attendance',
                'title' => 'Attendance requires attention',
                'message' => "Attendance is {$attendancePercentage}% for the selected period. Review affected classes and learners before deciding on an intervention.",
            ];
        }
        if ($averageScore !== null && $averageScore < 50) {
            $warnings[] = [
                'severity' => 'medium',
                'type' => 'academic',
                'title' => 'Published performance is below target',
                'message' => "The average published score is {$averageScore}%. Review the weakest subjects and confirm that all approved results are included.",
            ];
        }
        if ($attendanceTotal === 0) {
            $warnings[] = [
                'severity' => 'info',
                'type' => 'data_quality',
                'title' => 'No attendance records in this period',
                'message' => 'This is a data-availability notice, not a prediction. Confirm that attendance has been recorded for the selected dates.',
            ];
        }
        if ($publishedResults->isEmpty()) {
            $warnings[] = [
                'severity' => 'info',
                'type' => 'data_quality',
                'title' => 'No published results available',
                'message' => 'Only approved and published results are used here. Complete the result workflow before interpreting academic trends.',
            ];
        }

        return response()->json([
            'data' => [
                'school' => ['id' => $school->id, 'name' => $school->name],
                'period' => ['from' => $from->toDateString(), 'to' => now()->toDateString(), 'days' => $from->diffInDays(now())],
                'facts' => [
                    'active_students' => Student::where('school_id', $schoolId)->where('status', 'Active')->count(),
                    'attendance_percentage' => $attendancePercentage,
                    'attendance_records' => $attendanceTotal,
                    'published_result_count' => $publishedResults->count(),
                    'average_published_score' => $averageScore,
                ],
                'subject_averages' => $subjectAverages,
                'warnings' => $warnings,
                'is_forecast' => false,
                'disclaimer' => 'These are explainable summaries of records already stored in this school. They are not predictions and do not replace professional academic, pastoral, medical, or financial judgement.',
            ],
        ]);
    }
}
