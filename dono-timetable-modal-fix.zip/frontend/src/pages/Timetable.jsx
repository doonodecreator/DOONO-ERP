import { useEffect, useMemo, useState } from 'react';
import api from '../services/api';
import { useAuth } from '../context/AuthContext';
import { arrayFromResponse } from '../utils/response';
import PageContainer from '../components/layout/PageContainer';
import PageHeader from '../components/layout/PageHeader';
import LoadingSpinner from '../components/feedback/LoadingSpinner';
import EmptyState from '../components/feedback/EmptyState';
import DataTable from '../components/tables/DataTable';

const emptyForm = {
  academic_session_id: '',
  term_id: '',
  division_id: '',
  class_id: '',
  stream_id: '',
  subject_id: '',
  staff_id: '',
  day_of_week: 'Monday',
  start_time: '08:00',
  end_time: '08:45',
  room: '',
  is_active: true,
};

function apiErrorMessage(error, fallback) {
  const data = error?.response?.data;
  if (data?.errors && typeof data.errors === 'object') {
    const first = Object.values(data.errors).flat()?.[0];
    if (first) return first;
  }
  return data?.message || error?.message || fallback;
}

export default function Timetable() {
  const { permissions } = useAuth();
  const canManageTimetable = Array.isArray(permissions) && permissions.includes('manage_timetable');
  const [timetables, setTimetables] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [terms, setTerms] = useState([]);
  const [divisions, setDivisions] = useState([]);
  const [classes, setClasses] = useState([]);
  const [streams, setStreams] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [staff, setStaff] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState(emptyForm);

  useEffect(() => {
    loadInitialData();
  }, []);

  async function loadInitialData() {
    setLoading(true);
    setError('');
    const requests = await Promise.allSettled([
      api.get('/timetables'),
      api.get('/academic-sessions'),
      api.get('/terms'),
      api.get('/divisions'),
      api.get('/classes'),
      api.get('/streams'),
      api.get('/subjects'),
      api.get('/staff'),
    ]);

    const [tRes, sessionRes, termRes, divisionRes, classRes, streamRes, subjectRes, staffRes] = requests;
    if (tRes.status === 'fulfilled') setTimetables(arrayFromResponse(tRes.value));
    if (sessionRes.status === 'fulfilled') setSessions(arrayFromResponse(sessionRes.value));
    if (termRes.status === 'fulfilled') setTerms(arrayFromResponse(termRes.value));
    if (divisionRes.status === 'fulfilled') setDivisions(arrayFromResponse(divisionRes.value));
    if (classRes.status === 'fulfilled') setClasses(arrayFromResponse(classRes.value));
    if (streamRes.status === 'fulfilled') setStreams(arrayFromResponse(streamRes.value));
    if (subjectRes.status === 'fulfilled') setSubjects(arrayFromResponse(subjectRes.value));
    if (staffRes.status === 'fulfilled') setStaff(arrayFromResponse(staffRes.value));

    const failed = requests.find((result) => result.status === 'rejected');
    if (failed) setError(apiErrorMessage(failed.reason, 'Timetable data could not be loaded.'));
    setLoading(false);
  }

  const selectedTerms = useMemo(
    () => terms.filter((term) => !form.academic_session_id || String(term.academic_session_id) === String(form.academic_session_id)),
    [terms, form.academic_session_id],
  );

  const selectedClasses = useMemo(
    () => classes.filter((item) => !form.division_id || String(item.division_id) === String(form.division_id)),
    [classes, form.division_id],
  );

  const selectedStreams = useMemo(
    () => streams.filter((item) => !form.class_id || String(item.class_id) === String(form.class_id)),
    [streams, form.class_id],
  );

  function updateForm(name, value) {
    setForm((current) => {
      const next = { ...current, [name]: value };
      if (name === 'academic_session_id') next.term_id = '';
      if (name === 'division_id') {
        next.class_id = '';
        next.stream_id = '';
      }
      if (name === 'class_id') next.stream_id = '';
      return next;
    });
  }

  async function handleCreate(event) {
    event.preventDefault();
    setSaving(true);
    setError('');
    const payload = {
      ...form,
      academic_session_id: Number(form.academic_session_id),
      term_id: Number(form.term_id),
      division_id: Number(form.division_id),
      class_id: Number(form.class_id),
      stream_id: form.stream_id ? Number(form.stream_id) : null,
      subject_id: Number(form.subject_id),
      staff_id: form.staff_id ? Number(form.staff_id) : null,
      is_active: true,
    };

    try {
      await api.post('/timetables', payload);
      setShowModal(false);
      setForm(emptyForm);
      await loadInitialData();
    } catch (err) {
      setError(apiErrorMessage(err, 'Failed to save timetable slot.'));
    } finally {
      setSaving(false);
    }
  }

  const filteredTimetable = timetables.filter((item) => !selectedClass || String(item.class_id) === String(selectedClass));

  return (
    <PageContainer>
      <PageHeader
        title="Class Timetable & Schedules"
        subtitle={canManageTimetable ? 'Configure daily school periods, lecture times, and subject allocations.' : 'Review the school timetable and approved class schedules.'}
        action={canManageTimetable ? (
          <button
            type="button"
            aria-label="Add timetable slot"
            onClick={(event) => {
              event.preventDefault();
              event.stopPropagation();
              setError('');
              setForm({ ...emptyForm });
              setShowModal(true);
            }}
            style={{ pointerEvents: 'auto', touchAction: 'manipulation' }}
            className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700"
          >
            + Add Timetable Slot
          </button>
        ) : null}
      />

      {error && <div className="mb-6 flex items-center justify-between rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700"><span>{error}</span><button onClick={loadInitialData} className="font-semibold underline">Retry</button></div>}

      <div className="mb-6 flex items-center gap-4 rounded-xl border border-gray-100 bg-white p-4 shadow-sm">
        <label className="text-xs font-semibold text-gray-600" htmlFor="timetable-class-filter">Filter by Class:</label>
        <select id="timetable-class-filter" value={selectedClass} onChange={(event) => setSelectedClass(event.target.value)} className="rounded-lg border border-gray-200 bg-white px-3 py-2 text-sm">
          <option value="">All Classes</option>
          {classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}
        </select>
      </div>

      {loading ? <LoadingSpinner /> : filteredTimetable.length === 0 ? <EmptyState title="No timetable periods" message={canManageTimetable ? 'Use the add button to create the first slot.' : 'Timetable entries created by the school administrator will appear here.'} /> : (
        <DataTable
          columns={[
            { key: 'day_of_week', label: 'Day' },
            { key: 'class', label: 'Class', render: (item) => item.class?.name || `Class #${item.class_id}` },
            { key: 'subject', label: 'Subject', render: (item) => item.subject?.name || `Subject #${item.subject_id}` },
            { key: 'time', label: 'Time', render: (item) => `${item.start_time} - ${item.end_time}` },
          ]}
          data={Array.isArray(filteredTimetable) ? filteredTimetable : []}
          emptyMessage="No timetable periods recorded."
        />
      )}

      {showModal && (
        <div role="dialog" aria-modal="true" aria-labelledby="add-timetable-title" className="fixed inset-0 z-[100] flex items-start justify-center overflow-y-auto bg-black/50 p-4 sm:items-center">
          <div className="my-4 max-h-[calc(100vh-2rem)] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-xl">
            <h3 id="add-timetable-title" className="mb-4 text-lg font-bold text-gray-900">Add Timetable Slot</h3>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <SelectField label="Academic Session" value={form.academic_session_id} onChange={(value) => updateForm('academic_session_id', value)} options={sessions} placeholder="Select session..." required />
                <SelectField label="Term" value={form.term_id} onChange={(value) => updateForm('term_id', value)} options={selectedTerms} placeholder="Select term..." required />
                <SelectField label="Division" value={form.division_id} onChange={(value) => updateForm('division_id', value)} options={divisions} placeholder="Select division..." required />
                <SelectField label="Class" value={form.class_id} onChange={(value) => updateForm('class_id', value)} options={selectedClasses} placeholder="Select class..." required />
                <SelectField label="Stream" value={form.stream_id} onChange={(value) => updateForm('stream_id', value)} options={selectedStreams} placeholder="No stream / select..." />
                <SelectField label="Subject" value={form.subject_id} onChange={(value) => updateForm('subject_id', value)} options={subjects} placeholder="Select subject..." required />
                <SelectField label="Teacher (optional)" value={form.staff_id} onChange={(value) => updateForm('staff_id', value)} options={staff} placeholder="No teacher assigned" labelKey="full_name" />
                <label className="text-xs font-semibold text-gray-600">Day of Week<select value={form.day_of_week} onChange={(event) => updateForm('day_of_week', event.target.value)} className="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm">{['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'].map((day) => <option key={day} value={day}>{day}</option>)}</select></label>
                <label className="text-xs font-semibold text-gray-600">Start Time<input required type="time" value={form.start_time} onChange={(event) => updateForm('start_time', event.target.value)} className="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" /></label>
                <label className="text-xs font-semibold text-gray-600">End Time<input required type="time" value={form.end_time} onChange={(event) => updateForm('end_time', event.target.value)} className="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" /></label>
                <label className="text-xs font-semibold text-gray-600">Room (optional)<input value={form.room} onChange={(event) => updateForm('room', event.target.value)} className="mt-1 w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" /></label>
              </div>
              <div className="sticky bottom-0 flex justify-end gap-3 bg-white pt-3">
                <button type="button" onClick={() => setShowModal(false)} className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium text-gray-700">Cancel</button>
                <button type="submit" disabled={saving} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white disabled:opacity-50">{saving ? 'Saving...' : 'Save Slot'}</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </PageContainer>
  );
}

function SelectField({ label, value, onChange, options, placeholder, required = false, labelKey = 'name' }) {
  return (
    <label className="text-xs font-semibold text-gray-600">{label}<select required={required} value={value} onChange={(event) => onChange(event.target.value)} className="mt-1 w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm"><option value="">{placeholder}</option>{(Array.isArray(options) ? options : []).map((item) => <option key={item.id} value={item.id}>{item[labelKey] || item.name || item.title || `#${item.id}`}</option>)}</select></label>
  );
}
