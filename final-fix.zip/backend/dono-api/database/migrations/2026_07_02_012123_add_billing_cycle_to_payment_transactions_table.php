<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('payment_transactions', function (Blueprint $table) {

            $table->enum('billing_cycle', [

                'monthly',

                'quarterly',

                'half_yearly',

                'yearly',

            ])
            ->default('yearly')
            ->after('currency');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('payment_transactions', function (Blueprint $table) {

            $table->dropColumn('billing_cycle');
        });
    }
};
