<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\School;
use App\Models\Student;
use Illuminate\Http\Request;

class PublicIntegrationController extends Controller
{
    public function school(Request $request)
    {
        $school = $this->schoolFromKey($request);
        return response()->json(['data' => [
            'id' => $school->id,
            'name' => $school->name,
            'short_name' => $school->short_name,
            'school_type' => $school->school_type,
            'address' => $school->address,
            'phone' => $school->phone,
            'email' => $school->email,
        ]]);
    }

    public function fees(Request $request)
    {
        $school = $this->schoolFromKey($request);
        $fees = \App\Models\StudentFee::query()
            ->where('school_id', $school->id)
            ->with(['studentEnrollment.student:id,first_name,middle_name,last_name,admission_number'])
            ->withSum('payments as total_paid', 'amount_paid')
            ->latest('id')
            ->paginate(min(max($request->integer('per_page', 50), 1), 200));
        $fees->getCollection()->transform(fn ($fee) => [
            'id' => $fee->id,
            'invoice_number' => $fee->invoice_number,
            'student' => $fee->studentEnrollment?->student?->only(['id', 'first_name', 'middle_name', 'last_name', 'admission_number']),
            'amount' => $fee->amount,
            'discount' => $fee->discount,
            'amount_due' => $fee->amount_due,
            'total_paid' => $fee->total_paid,
            'due_date' => $fee->due_date?->toDateString(),
            'status' => $fee->status,
        ]);
        return response()->json($fees);
    }

    public function students(Request $request)
    {
        $school = $this->schoolFromKey($request);
        $students = Student::query()->where('school_id', $school->id)->where('status', 'Active')->with(['class:id,name', 'stream:id,name'])->orderBy('last_name')->orderBy('first_name')->paginate(min(max($request->integer('per_page', 50), 1), 200));
        $students->getCollection()->transform(fn (Student $student) => [
            'id' => $student->id,
            'admission_number' => $student->admission_number,
            'full_name' => $student->full_name,
            'class' => $student->class?->name,
            'stream' => $student->stream?->name,
            'status' => $student->status,
        ]);
        return response()->json($students);
    }

    private function schoolFromKey(Request $request): School
    {
        $schoolId = (int) $request->attributes->get('school_api_key_school_id');
        abort_unless($schoolId > 0, 401, 'The API key has no school context.');
        return School::query()->select(['id', 'name', 'short_name', 'school_type', 'address', 'phone', 'email'])->findOrFail($schoolId);
    }
}
