<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AcademicSession;
use App\Models\ClassModel;
use App\Models\Division;
use App\Models\Fee;
use App\Models\RoleInvitation;
use App\Models\School;
use App\Models\SchoolSetupChecklistState;
use App\Models\Stream;
use App\Models\Subject;
use App\Models\Term;
use App\Services\CurrentContextService;
use Illuminate\Http\Request;

class SchoolSetupController extends Controller
{
    public function __construct(protected CurrentContextService $context) {}

    public function progress(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        $school = School::findOrFail($schoolId);
        $counts = $this->counts($schoolId);
        $definitions = $this->stepDefinitions();
        $states = SchoolSetupChecklistState::query()->where('school_id', $schoolId)->get()->keyBy('step_key');

        $steps = collect($definitions)->map(function (array $definition) use ($counts, $states): array {
            $complete = $this->isComplete($definition['key'], $counts);
            $blockedBy = collect($definition['requires'])
                ->filter(fn (string $requiredKey) => ! $this->isComplete($requiredKey, $counts))
                ->values()
                ->all();
            $state = $states->get($definition['key']);

            return [
                ...$definition,
                'complete' => $complete,
                'blocked' => $blockedBy !== [],
                'blocked_by' => $blockedBy,
                'acknowledged' => (bool) $state?->acknowledged,
                'last_viewed_at' => $state?->last_viewed_at,
                'acknowledged_at' => $state?->acknowledged_at,
            ];
        })->values();

        return response()->json([
            'success' => true,
            'school' => ['id' => $school->id, 'name' => $school->name],
            'counts' => $counts,
            'completed_steps' => $steps->where('complete', true)->count(),
            'acknowledged_steps' => $steps->where('acknowledged', true)->count(),
            'total_steps' => $steps->count(),
            'steps' => $steps,
        ]);
    }

    public function updateStep(Request $request, string $stepKey)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless(collect($this->stepDefinitions())->pluck('key')->contains($stepKey), 404, 'Setup step not found.');
        $data = $request->validate(['acknowledged' => ['required', 'boolean']]);

        $state = SchoolSetupChecklistState::updateOrCreate(
            ['school_id' => $schoolId, 'step_key' => $stepKey],
            [
                'acknowledged' => (bool) $data['acknowledged'],
                'last_viewed_by' => $request->user()->id,
                'last_viewed_at' => now(),
                'acknowledged_at' => $data['acknowledged'] ? now() : null,
            ],
        );

        return response()->json(['message' => 'Setup checklist state saved.', 'data' => $state]);
    }

    private function counts(int $schoolId): array
    {
        $leadershipComplete = RoleInvitation::query()
            ->where('school_id', $schoolId)
            ->where('status', 'accepted')
            ->whereNotNull('accepted_user_id')
            ->whereHas('acceptedUser.roles', function ($query) use ($schoolId): void {
                $query->whereIn('roles.slug', ['principal', 'vice_principal_academic', 'vice_principal_admin'])
                    ->where('user_roles.school_id', $schoolId);
            })
            ->exists();

        return [
            'profile' => 1,
            'academic_sessions' => AcademicSession::where('school_id', $schoolId)->count(),
            'terms' => Term::whereHas('academicSession', fn ($query) => $query->where('school_id', $schoolId))->count(),
            'divisions' => Division::where('school_id', $schoolId)->count(),
            'classes' => ClassModel::whereHas('division', fn ($query) => $query->where('school_id', $schoolId))->count(),
            'streams' => Stream::whereHas('class.division', fn ($query) => $query->where('school_id', $schoolId))->count(),
            'subjects' => Subject::where('school_id', $schoolId)->count(),
            'fees' => Fee::where('school_id', $schoolId)->count(),
            'leadership' => $leadershipComplete ? 1 : 0,
        ];
    }

    private function stepDefinitions(): array
    {
        return [
            ['key' => 'profile', 'label' => 'School profile', 'page' => 'settings', 'requires' => []],
            ['key' => 'academic_sessions', 'label' => 'Academic session', 'page' => 'academic-sessions', 'requires' => []],
            ['key' => 'terms', 'label' => 'Terms', 'page' => 'terms', 'requires' => ['academic_sessions']],
            ['key' => 'divisions', 'label' => 'Divisions', 'page' => 'divisions', 'requires' => ['academic_sessions']],
            ['key' => 'classes', 'label' => 'Classes', 'page' => 'classes', 'requires' => ['divisions']],
            ['key' => 'streams', 'label' => 'Streams', 'page' => 'streams', 'requires' => ['classes']],
            ['key' => 'subjects', 'label' => 'Subjects', 'page' => 'subjects', 'requires' => ['academic_sessions']],
            ['key' => 'fees', 'label' => 'Fee structure', 'page' => 'fees', 'requires' => ['academic_sessions', 'terms']],
            ['key' => 'leadership', 'label' => 'Leadership assignment', 'page' => 'role-invitations', 'requires' => ['profile']],
        ];
    }

    private function isComplete(string $key, array $counts): bool
    {
        return (int) ($counts[$key] ?? 0) > 0;
    }

}
