<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreStudentFeeRequest;
use App\Http\Requests\UpdateStudentFeeRequest;
use App\Http\Resources\StudentFeeResource;
use App\Models\StudentFee;
use App\Services\CurrentContextService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

class StudentFeeController extends Controller
{
    public function __construct(protected CurrentContextService $context) {}

    public function index(Request $request)
    {
        $schoolId = $this->context->currentSchool($request->user())?->id;
        abort_unless($schoolId, 409, 'Select an active school before viewing invoices.');

        return StudentFeeResource::collection(
            StudentFee::when($schoolId, function ($query) use ($schoolId) {
                $query->whereHas('studentEnrollment.student', fn($q) => $q->where('school_id', $schoolId));
            })
            ->with([
                'studentEnrollment.student',
                'feeCategory',
                'academicSession',
                'term',
                'payments',
            ])->latest()->paginate(10)
        );
    }

    public function store(StoreStudentFeeRequest $request)
    {
        $data = $request->validated();
        $schoolId = $this->context->currentSchool($request->user())?->id;
        abort_unless($schoolId, 409, 'Select an active school before creating an invoice.');
        $studentFee = DB::transaction(function () use ($data, $schoolId): StudentFee {
            $settings = DB::table('school_settings')->where('school_id', $schoolId)->lockForUpdate()->first();
            if (! $settings) {
                DB::table('school_settings')->insert(['school_id' => $schoolId, 'invoice_prefix' => 'INV', 'next_invoice_number' => 1, 'created_at' => now(), 'updated_at' => now()]);
                $settings = DB::table('school_settings')->where('school_id', $schoolId)->lockForUpdate()->first();
            }
            $prefix = strtoupper(trim((string) ($settings->invoice_prefix ?: 'INV')));
            $sequence = max(1, (int) ($settings->next_invoice_number ?: 1));
            $invoiceNumber = $prefix.'-'.str_pad((string) $sequence, 6, '0', STR_PAD_LEFT);
            DB::table('school_settings')->where('school_id', $schoolId)->update(['next_invoice_number' => $sequence + 1, 'updated_at' => now()]);
            return StudentFee::create([...$data, 'school_id' => $schoolId, 'invoice_number' => $invoiceNumber]);
        });

        return (new StudentFeeResource(
            $studentFee->load([
                'studentEnrollment.student',
                'feeCategory',
                'academicSession',
                'term',
                'payments',
            ])
        ))
        ->response()
        ->setStatusCode(201);
    }

    public function show(Request $request, StudentFee $studentFee)
    {
        $this->assertBelongsToCurrentSchool($request, $studentFee);

        return new StudentFeeResource(
            $studentFee->load([
                'studentEnrollment.student',
                'feeCategory',
                'academicSession',
                'term',
                'payments',
            ])
        );
    }

    public function update(UpdateStudentFeeRequest $request, StudentFee $studentFee)
    {
        $this->assertBelongsToCurrentSchool($request, $studentFee);
        $data = $request->validated();
        unset($data['invoice_number'], $data['school_id']);
        $studentFee->update($data);

        return new StudentFeeResource(
            $studentFee->load([
                'studentEnrollment.student',
                'feeCategory',
                'academicSession',
                'term',
                'payments',
            ])
        );
    }

    public function destroy(Request $request, StudentFee $studentFee)
    {
        $this->assertBelongsToCurrentSchool($request, $studentFee);
        $studentFee->delete();

        return response()->json([
            'message' => 'Student fee deleted successfully.',
        ]);
    }

    private function assertBelongsToCurrentSchool(Request $request, StudentFee $studentFee): void
    {
        $schoolId = $this->context->currentSchool($request->user())?->id;
        $studentFee->loadMissing('studentEnrollment.student');

        if ((int) $studentFee->studentEnrollment?->student?->school_id !== (int) $schoolId) {
            throw new NotFoundHttpException('Invoice not found in the current school.');
        }
    }
}
