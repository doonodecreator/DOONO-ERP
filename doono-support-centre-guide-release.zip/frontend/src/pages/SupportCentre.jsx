import { useEffect, useMemo, useState } from "react";
import api from "../services/api";
import { getPrimaryRoleSlug } from "../utils/role";
import { paginatedFromResponse } from "../utils/response";
import { GUIDE_MODULE_KEYS, moduleGuide, roleGuide } from "../config/guideKnowledge";
import { ARCHITECTURE_MODULES } from "../config/architectureModules";
import PageHeader from "../components/layout/PageHeader";
import DataTable from "../components/tables/DataTable";
import LoadingSpinner from "../components/feedback/LoadingSpinner";
import EmptyState from "../components/feedback/EmptyState";
import { useAuth } from "../context/AuthContext";

const initialForm = { subject: "", category: "general", priority: "normal", description: "" };
const categoryLabels = {
  general: "General question",
  account_access: "Account or login",
  billing: "Billing or subscription",
  academic: "Academic setup or results",
  finance: "Fees or payments",
  technical: "Technical problem",
  security: "Security concern",
  data_request: "Data request",
};
const statusLabels = {
  open: "Open",
  in_progress: "In progress",
  waiting_on_user: "Waiting for your reply",
  resolved: "Resolved",
  closed: "Closed",
};

function formatDate(value) {
  return value ? new Date(value).toLocaleString() : "—";
}

export default function SupportCentre() {
  const { roles, isPlatformAdmin, isOrganizationOwner, school } = useAuth();
  const role = getPrimaryRoleSlug({ roles, isPlatformAdmin, isOrganizationOwner, school });
  const [tickets, setTickets] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [selectedTicket, setSelectedTicket] = useState(null);
  const [articles, setArticles] = useState([]);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");
  const [category, setCategory] = useState("");
  const [form, setForm] = useState(initialForm);
  const [reply, setReply] = useState("");
  const [showRequestForm, setShowRequestForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const roleHelp = useMemo(() => roleGuide(role), [role]);

  useEffect(() => {
    const roleArticle = {
      id: "role-overview",
      title: `How to use DOONO as a ${roleHelp.label}`,
      category: "Your role",
      purpose: roleHelp.intro,
      steps: Array.isArray(roleHelp.steps) ? roleHelp.steps : [],
      next: "Start with the first incomplete step, then return to your dashboard to confirm the result.",
    };
    const moduleArticles = GUIDE_MODULE_KEYS.map((key) => {
      const guide = moduleGuide(key);
      return {
        id: `module-${key}`,
        title: guide.title,
        category: "Module guide",
        purpose: guide.purpose,
        steps: Array.isArray(guide.steps) ? guide.steps : [],
        next: guide.next,
      };
    });
    setArticles([roleArticle, ...moduleArticles]);
  }, [roleHelp]);

  async function loadTickets(page = 1) {
    setLoading(true);
    setError("");
    try {
      const response = await api.get("/support-tickets", { params: { page, per_page: 15, search: search || undefined, status: status || undefined, category: category || undefined } });
      const result = paginatedFromResponse(response);
      setTickets(Array.isArray(result.data) ? result.data : []);
      setPagination(result.meta);
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Unable to load support requests.");
      setTickets([]);
      setPagination(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadTickets(); }, [status, category]);

  async function openTicket(ticket) {
    setError("");
    try {
      const response = await api.get(`/support-tickets/${ticket.id}`);
      setSelectedTicket(response?.data?.data || null);
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Unable to open this support request.");
    }
  }

  async function submitTicket(event) {
    event.preventDefault();
    setSaving(true);
    setError("");
    setMessage("");
    try {
      const response = await api.post("/support-tickets", form);
      setMessage(response?.data?.message || "Support request submitted.");
      setForm(initialForm);
      setShowRequestForm(false);
      await loadTickets();
      if (response?.data?.data) setSelectedTicket(response.data.data);
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Unable to submit this support request.");
    } finally {
      setSaving(false);
    }
  }

  async function submitReply(event) {
    event.preventDefault();
    if (!selectedTicket?.id || !reply.trim()) return;
    setSaving(true);
    setError("");
    try {
      const response = await api.post(`/support-tickets/${selectedTicket.id}/replies`, { body: reply.trim() });
      setSelectedTicket(response?.data?.data || selectedTicket);
      setReply("");
      setMessage(response?.data?.message || "Reply added.");
      await loadTickets(pagination?.current_page || 1);
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Unable to add your reply.");
    } finally {
      setSaving(false);
    }
  }

  async function updateTicketStatus(nextStatus) {
    if (!selectedTicket?.id || !isPlatformAdmin) return;
    setSaving(true);
    setError("");
    try {
      const response = await api.patch(`/support-tickets/${selectedTicket.id}/status`, { status: nextStatus });
      setSelectedTicket(response?.data?.data || selectedTicket);
      setMessage(response?.data?.message || "Support ticket updated.");
      await loadTickets(pagination?.current_page || 1);
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Unable to update the support ticket.");
    } finally {
      setSaving(false);
    }
  }

  const filteredArticles = useMemo(() => {
    const query = search.trim().toLowerCase();
    if (!query) return articles;
    return articles.filter((article) => `${article.title} ${article.category} ${article.purpose} ${article.next} ${(article.steps || []).map((step) => `${step.title} ${step.detail}`).join(" ")}`.toLowerCase().includes(query));
  }, [articles, search]);

  const columns = [
    { key: "ticket_number", label: "Reference", render: (ticket) => <button type="button" className="font-semibold text-indigo-700 underline" onClick={() => openTicket(ticket)}>{ticket.ticket_number}</button> },
    { key: "subject", label: "Request", render: (ticket) => <button type="button" className="text-left font-semibold text-slate-900" onClick={() => openTicket(ticket)}>{ticket.subject}</button> },
    { key: "category", label: "Category", render: (ticket) => categoryLabels[ticket.category] || ticket.category },
    { key: "priority", label: "Priority", render: (ticket) => <span className={`rounded-full px-2 py-1 text-xs font-bold ${ticket.priority === "urgent" ? "bg-rose-100 text-rose-700" : ticket.priority === "high" ? "bg-amber-100 text-amber-700" : "bg-slate-100 text-slate-600"}`}>{ticket.priority}</span> },
    { key: "status", label: "Status", render: (ticket) => statusLabels[ticket.status] || ticket.status },
    { key: "updated_at", label: "Updated", render: (ticket) => formatDate(ticket.updated_at) },
  ];

  return (
    <div className="space-y-6">
      <PageHeader title="Support Centre" subtitle="Find a clear answer, follow the correct workflow, or send a support request that can be tracked from start to finish." action={<button type="button" className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white" onClick={() => setShowRequestForm((open) => !open)}>{showRequestForm ? "Close request form" : "Ask for support"}</button>} />

      {error && <div role="alert" className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}<button type="button" onClick={() => loadTickets()} className="ml-2 font-semibold underline">Retry</button></div>}
      {message && <div role="status" className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700">{message}</div>}

      <section className="rounded-xl border border-indigo-100 bg-indigo-50 p-5">
        <p className="text-xs font-bold uppercase tracking-wide text-indigo-700">Start here</p>
        <h2 className="mt-1 text-xl font-bold text-indigo-950">You are using DOONO as {roleHelp.label}</h2>
        <p className="mt-2 max-w-3xl text-sm leading-6 text-indigo-900">{roleHelp.intro}</p>
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {(Array.isArray(roleHelp.steps) ? roleHelp.steps.slice(0, 3) : []).map((step, index) => <button key={`${step.title}-${index}`} type="button" onClick={() => setSearch(step.title)} className="rounded-lg border border-indigo-200 bg-white p-4 text-left shadow-sm"><span className="text-xs font-bold text-indigo-600">Step {index + 1}</span><span className="mt-1 block font-semibold text-slate-900">{step.title}</span><span className="mt-1 block text-xs leading-5 text-slate-600">{step.detail}</span></button>)}
        </div>
      </section>

      {showRequestForm && <form onSubmit={submitTicket} className="space-y-4 rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><div><h2 className="text-lg font-bold text-slate-900">Create a support request</h2><p className="mt-1 text-sm text-slate-500">Describe what you expected, what happened, and where it happened. Never include a password or payment-card number.</p></div><div className="grid gap-4 md:grid-cols-3"><label className="block text-sm font-semibold text-slate-700 md:col-span-2">Subject<input required maxLength={180} value={form.subject} onChange={(event) => setForm({ ...form, subject: event.target.value })} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-normal" placeholder="Example: I cannot publish the term result" /></label><label className="block text-sm font-semibold text-slate-700">Priority<select value={form.priority} onChange={(event) => setForm({ ...form, priority: event.target.value })} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-normal"><option value="low">Low</option><option value="normal">Normal</option><option value="high">High</option><option value="urgent">Urgent</option></select></label></div><label className="block text-sm font-semibold text-slate-700">Category<select value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-normal">{Object.entries(categoryLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label><label className="block text-sm font-semibold text-slate-700">Explain the problem<textarea required minLength={10} maxLength={10000} rows={6} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-normal" placeholder="Tell us the steps you took, the error message, and the school/module involved." /></label><div className="flex flex-wrap gap-3"><button type="submit" disabled={saving} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">{saving ? "Submitting…" : "Submit support request"}</button><button type="button" onClick={() => setShowRequestForm(false)} className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">Cancel</button></div></form>}

      <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex flex-wrap items-end gap-3"><label className="min-w-[220px] flex-1 text-sm font-semibold text-slate-700">Search help and requests<input value={search} onChange={(event) => setSearch(event.target.value)} onKeyDown={(event) => { if (event.key === "Enter") loadTickets(); }} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-normal" placeholder="Search fees, login, results, timetable..." /></label><label className="text-sm font-semibold text-slate-700">Request status<select value={status} onChange={(event) => setStatus(event.target.value)} className="mt-1 rounded-lg border border-slate-300 px-3 py-2 font-normal"><option value="">All statuses</option>{Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label><label className="text-sm font-semibold text-slate-700">Category<select value={category} onChange={(event) => setCategory(event.target.value)} className="mt-1 rounded-lg border border-slate-300 px-3 py-2 font-normal"><option value="">All categories</option>{Object.entries(categoryLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label><button type="button" onClick={() => loadTickets()} className="rounded-lg bg-slate-800 px-4 py-2 text-sm font-semibold text-white">Search</button></div></section>

      <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="text-lg font-bold text-slate-900">Searchable help</h2><p className="mt-1 text-sm text-slate-500">Select an explanation below. It tells you what the workspace is for, what to do first, and what should happen next.</p>{filteredArticles.length === 0 ? <EmptyState title="No matching guide found" message="Try a simpler word, or submit a support request if the explanation you need is missing." /> : <div className="mt-4 grid gap-3 md:grid-cols-2">{filteredArticles.slice(0, 12).map((article) => <details key={article.id} className="rounded-lg border border-slate-200 p-4"><summary className="cursor-pointer font-semibold text-slate-900">{article.title}<span className="ml-2 text-xs font-normal text-slate-500">{article.category}</span></summary><p className="mt-3 text-sm leading-6 text-slate-600">{article.purpose}</p><ol className="mt-3 space-y-2">{(Array.isArray(article.steps) ? article.steps : []).map((step, index) => <li key={`${article.id}-${index}`} className="flex gap-2 text-sm leading-6 text-slate-700"><span className="font-bold text-indigo-600">{index + 1}.</span><span><strong>{step?.title || "Do this"}</strong>{step?.detail ? ` — ${step.detail}` : ""}</span></li>)}</ol><p className="mt-3 rounded-lg bg-slate-50 p-3 text-sm text-slate-600"><strong>Next:</strong> {article.next}</p></details>)}</div>}</section>

      <section className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm"><h2 className="text-lg font-bold text-slate-900">My support requests</h2><p className="mt-1 text-sm text-slate-500">Every request receives a reference number. Use it when contacting the DOONO team outside the software.</p><div className="mt-4"><DataTable columns={columns} data={tickets} loading={loading} emptyTitle="No support requests yet" emptyMessage="If the guide does not answer your question, select Ask for support above." rowKey={(ticket) => ticket.id} pagination={pagination} onPageChange={loadTickets} /></div></section>

      {selectedTicket && <section className="rounded-xl border border-indigo-200 bg-white p-5 shadow-sm"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-wide text-indigo-600">{selectedTicket.ticket_number}</p><h2 className="mt-1 text-xl font-bold text-slate-900">{selectedTicket.subject}</h2><p className="mt-1 text-sm text-slate-500">{categoryLabels[selectedTicket.category] || selectedTicket.category} · {selectedTicket.priority} priority · {statusLabels[selectedTicket.status] || selectedTicket.status}</p></div><button type="button" onClick={() => setSelectedTicket(null)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700">Close</button></div><div className="mt-4 space-y-3">{(Array.isArray(selectedTicket.messages) ? selectedTicket.messages : []).map((item) => <article key={item.id} className={`rounded-lg p-4 ${item.is_internal_note ? "bg-amber-50" : "bg-slate-50"}`}><div className="flex flex-wrap justify-between gap-2 text-xs text-slate-500"><span className="font-semibold text-slate-700">{item.user?.name || "DOONO Support"}{item.is_internal_note ? " · Internal note" : ""}</span><span>{formatDate(item.created_at)}</span></div><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-700">{item.body}</p></article>)}</div><form onSubmit={submitReply} className="mt-4 flex flex-col gap-3"><label className="text-sm font-semibold text-slate-700">Add a reply<textarea required minLength={2} maxLength={10000} rows={4} value={reply} onChange={(event) => setReply(event.target.value)} className="mt-1 w-full rounded-lg border border-slate-300 px-3 py-2 font-normal" placeholder="Add information or answer the support team’s question." /></label><div className="flex flex-wrap gap-3"><button type="submit" disabled={saving || !reply.trim()} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">{saving ? "Sending…" : "Send reply"}</button>{isPlatformAdmin && <select disabled={saving} value={selectedTicket.status} onChange={(event) => updateTicketStatus(event.target.value)} className="rounded-lg border border-slate-300 px-3 py-2 text-sm font-semibold text-slate-700">{Object.entries(statusLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select>}</div></form></section>}

      <section className="rounded-xl border border-amber-200 bg-amber-50 p-5 text-sm leading-6 text-amber-900"><h2 className="font-bold">What support can and cannot do</h2><p className="mt-1">Support can explain workflows, investigate errors, review access problems, and track platform incidents. Support will never ask for your password, one-time code, or complete payment-card details. For urgent safety, safeguarding, or payment concerns, contact your school leadership or payment provider immediately as well as opening a support request.</p></section>
    </div>
  );
}
