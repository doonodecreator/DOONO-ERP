<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\TransportAllocation;
use App\Models\TransportRoute;
use App\Services\CurrentContextService;
use Illuminate\Http\Request;

class TransportAllocationController extends Controller
{
    public function __construct(protected CurrentContextService $context) {}

    public function index(Request $request)
    {
        $schoolId = $this->currentSchoolId($request);
        return response()->json(
            TransportAllocation::where('school_id', $schoolId)
                ->with(['route.vehicle', 'student'])
                ->latest()
                ->paginate(15)
        );
    }

    public function store(Request $request)
    {
        $schoolId = $this->currentSchoolId($request);
        $validated = $request->validate([
            'transport_route_id' => 'required|exists:transport_routes,id',
            'student_id' => 'required|exists:students,id|unique:transport_allocations,student_id',
            'pickup_point' => 'nullable|string|max:255',
        ]);

        abort_unless(TransportRoute::whereKey($validated['transport_route_id'])->where('school_id', $schoolId)->exists(), 403, 'The selected route does not belong to this school.');
        abort_unless(Student::whereKey($validated['student_id'])->where('school_id', $schoolId)->exists(), 403, 'The selected student does not belong to this school.');

        $allocation = TransportAllocation::create([...$validated, 'school_id' => $schoolId]);
        return response()->json(['message' => 'Student allocated to route successfully.', 'data' => $allocation->load(['route.vehicle', 'student'])], 201);
    }

    private function currentSchoolId(Request $request): int
    {
        $schoolId = $request->attributes->get('current_school_id') ?? $this->context->currentSchool($request->user())?->id;
        abort_unless($schoolId, 409, 'No active school.');
        return (int) $schoolId;
    }
}
