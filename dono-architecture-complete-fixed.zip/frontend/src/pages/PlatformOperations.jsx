import { useEffect, useState } from "react";
import api from "../services/api";
import PageContainer from "../components/layout/PageContainer";
import PageHeader from "../components/layout/PageHeader";
import LoadingSpinner from "../components/feedback/LoadingSpinner";
import EmptyState from "../components/feedback/EmptyState";

const modeMeta = {
  payments: { title: "Payments & Invoices", subtitle: "Platform revenue and payment transaction monitoring." },
  currency: { title: "Countries / Currency", subtitle: "Manage the currencies available to platform plans." },
  email: { title: "Email & SMS Settings", subtitle: "Control platform notification preferences." },
  logs: { title: "Backups & Logs", subtitle: "Review platform activity and operational records." },
  health: { title: "System Health", subtitle: "Inspect application, database, storage, and queue health." },
};

const arrayFrom = (response) => { const value = response?.data?.data ?? response?.data ?? []; if (Array.isArray(value)) return value; if (Array.isArray(value?.data)) return value.data; return []; };

export default function PlatformOperations({ mode = "health" }) {
  const meta = modeMeta[mode] || modeMeta.health;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function load() {
    try {
      setLoading(true); setError("");
      if (mode === "health") setData((await api.get("/platform/system-health"))?.data?.data || {});
      else if (mode === "payments") { const response = await api.get("/admin/revenue-dashboard"); setData(response?.data?.data || response?.data || {}); }
      else if (mode === "currency") setData({ countries: arrayFrom(await api.get("/countries")), currencies: arrayFrom(await api.get("/currencies")) });
      else if (mode === "logs") setData({ logs: arrayFrom(await api.get("/audit-logs", { params: { scope: "platform", per_page: 50 } })) });
      else if (mode === "email") { const response = await api.get("/system-settings"); setData(response?.data?.data || response?.data || {}); }
    } catch (err) { setError(err.response?.data?.message || `Unable to load ${meta.title.toLowerCase()}.`); setData(null); } finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [mode]);

  async function updateNotifications(event) {
    event.preventDefault();
    try { setSaving(true); setMessage(""); await api.put("/system-settings", { email_notifications: Boolean(data.email_notifications), sms_notifications: Boolean(data.sms_notifications) }); setMessage("Notification settings saved."); await load(); } catch (err) { setError(err.response?.data?.message || "Unable to save notification settings."); } finally { setSaving(false); }
  }

  return <PageContainer><PageHeader title={meta.title} subtitle={meta.subtitle} />{error && <div role="alert" className="mb-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error} <button type="button" onClick={load} className="ml-2 underline">Retry</button></div>}{message && <div role="status" className="mb-4 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">{message}</div>}{loading ? <LoadingSpinner /> : mode === "health" ? <div className="grid gap-4 sm:grid-cols-2">{Object.entries(data || {}).map(([key, value]) => <div key={key} className="rounded-xl border bg-white p-4 shadow-sm"><p className="text-sm capitalize text-slate-500">{key.replaceAll("_", " ")}</p><p className="mt-1 text-xl font-bold text-slate-900">{String(value)}</p></div>)}</div> : mode === "currency" ? <div className="grid gap-6 md:grid-cols-2"><section className="rounded-xl border bg-white p-4"><h2 className="font-semibold">Countries</h2>{data?.countries?.length ? <ul className="mt-3 space-y-2">{data.countries.map((country) => <li key={country.id} className="border-b py-2 text-sm">{country.name} {country.code ? `(${country.code})` : ""}</li>)}</ul> : <EmptyState title="No countries" message="No country records are available." />}</section><section className="rounded-xl border bg-white p-4"><h2 className="font-semibold">Currencies</h2>{data?.currencies?.length ? <ul className="mt-3 space-y-2">{data.currencies.map((currency) => <li key={currency.id} className="border-b py-2 text-sm">{currency.name} ({currency.code})</li>)}</ul> : <EmptyState title="No currencies" message="No currency records are available." />}</section></div> : mode === "email" ? <form onSubmit={updateNotifications} className="max-w-xl space-y-4 rounded-xl border bg-white p-5 shadow-sm"><label className="flex items-center gap-3"><input type="checkbox" checked={Boolean(data?.email_notifications)} onChange={(event) => setData({ ...data, email_notifications: event.target.checked })} /> Email notifications</label><label className="flex items-center gap-3"><input type="checkbox" checked={Boolean(data?.sms_notifications)} onChange={(event) => setData({ ...data, sms_notifications: event.target.checked })} /> SMS notifications</label><button disabled={saving} className="rounded-lg bg-indigo-600 px-4 py-2 font-semibold text-white disabled:opacity-60">{saving ? "Saving..." : "Save settings"}</button></form> : mode === "logs" ? <div className="space-y-3">{data?.logs?.length ? data.logs.map((log) => <article key={log.id} className="rounded-xl border bg-white p-4 shadow-sm"><p className="font-semibold">{log.description || log.action}</p><p className="text-xs text-slate-500">{log.created_at ? new Date(log.created_at).toLocaleString() : ""}</p></article>) : <EmptyState title="No platform logs" message="Platform activity will appear here." />}</div> : <div className="space-y-4 rounded-xl border bg-white p-5 shadow-sm"><pre className="overflow-auto text-sm text-slate-700">{JSON.stringify(data || {}, null, 2)}</pre></div>}</PageContainer>;
}
