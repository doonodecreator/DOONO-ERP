<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class PlatformOperationsController extends Controller
{
    public function health()
    {
        $database = 'down';
        try {
            DB::select('select 1');
            $database = 'up';
        } catch (\Throwable) {
            // Keep the response safe and useful to the platform owner.
        }

        return response()->json([
            'data' => [
                'application' => 'up',
                'database' => $database,
                'cache' => config('cache.default'),
                'queue' => config('queue.default'),
                'storage' => is_writable(storage_path()) ? 'writable' : 'not_writable',
                'migrations_table' => Schema::hasTable('migrations'),
                'checked_at' => now()->toIso8601String(),
            ],
        ]);
    }
}
