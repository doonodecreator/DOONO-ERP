<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CbtAssessment;
use App\Models\CbtAssessmentQuestion;
use App\Models\CbtAttemptAnswer;
use App\Models\AssessmentStructure;
use App\Models\Result;
use App\Models\ResultSubmission;
use App\Models\ReportCard;
use App\Services\Academic\ResultEntryService;
use App\Services\Academic\ResultSubmissionService;
use App\Models\CbtQuestion;
use App\Models\Student;
use App\Models\StudentEnrollment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CbtAssessmentController extends Controller
{
    public function __construct(
        protected ResultSubmissionService $submissionService,
        protected ResultEntryService $resultEntryService
    ) {
    }

    public function index(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        $assessments = CbtAssessment::where('school_id', $schoolId)
            ->with(['class:id,name', 'subject:id,name', 'academicSession:id,name', 'term:id,name', 'creator:id,name'])
            ->withCount(['questions', 'attempts'])
            ->latest()
            ->paginate(min(max($request->integer('per_page', 25), 1), 100));

        return response()->json($assessments);
    }

    public function store(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless($this->isAcademicLeader($request, $schoolId), 403, 'Only academic leadership can assemble CBT assessments.');
        $data = $request->validate([
            'title' => ['required', 'string', 'max:255'],
            'examination_id' => ['nullable', 'integer', 'exists:examinations,id'],
            'class_id' => ['required', 'integer', 'exists:classes,id'],
            'subject_id' => ['required', 'integer', 'exists:subjects,id'],
            'academic_session_id' => ['required', 'integer', 'exists:academic_sessions,id'],
            'term_id' => ['required', 'integer', 'exists:terms,id'],
            'instructions' => ['nullable', 'string', 'max:5000'],
            'duration_minutes' => ['required', 'integer', 'min:1', 'max:360'],
            'pass_mark' => ['nullable', 'integer', 'min:0'],
            'result_weight' => ['required', 'integer', 'min:1', 'max:100'],
            'max_attempts' => ['required', 'integer', 'min:1', 'max:3'],
            'available_from' => ['nullable', 'date'],
            'available_until' => ['nullable', 'date', 'after:available_from'],
            'shuffle_questions' => ['boolean'],
            'question_ids' => ['required', 'array', 'min:1'],
            'question_ids.*' => ['integer', 'distinct'],
        ]);

        abort_unless(DB::table('classes')->where('id', $data['class_id'])->where('school_id', $schoolId)->exists(), 422, 'The selected class does not belong to the active school.');
        abort_unless(DB::table('subjects')->where('id', $data['subject_id'])->where('school_id', $schoolId)->exists(), 422, 'The selected subject does not belong to the active school.');
        abort_unless(DB::table('academic_sessions')->where('id', $data['academic_session_id'])->where('school_id', $schoolId)->exists(), 422, 'The selected session does not belong to the active school.');
        abort_unless(DB::table('terms')->where('id', $data['term_id'])->where('academic_session_id', $data['academic_session_id'])->exists(), 422, 'The selected term does not belong to the selected session.');

        $questions = CbtQuestion::where('school_id', $schoolId)
            ->whereIn('id', $data['question_ids'])
            ->where('is_active', true)
            ->where('approval_status', 'approved')
            ->get();
        abort_unless($questions->count() === count($data['question_ids']), 422, 'Every selected question must be active, approved, and owned by the active school.');

        if (!empty($data['examination_id'])) {
            abort_unless(DB::table('examinations')->where('id', $data['examination_id'])->where('school_id', $schoolId)->exists(), 422, 'The selected examination does not belong to the active school.');
        }

        $assessment = DB::transaction(function () use ($data, $questions, $schoolId, $request) {
            $totalMarks = max(1, (int) $questions->sum('marks'));
            $structure = AssessmentStructure::firstOrCreate(
                ['school_id' => $schoolId, 'name' => 'CBT: '.$data['title']],
                ['maximum_marks' => $totalMarks, 'percentage' => (int) $data['result_weight'], 'display_order' => 99, 'is_active' => true]
            );
            $submission = ResultSubmission::firstOrCreate(
                ['school_id' => $schoolId, 'class_id' => $data['class_id'], 'subject_id' => $data['subject_id'], 'academic_session_id' => $data['academic_session_id'], 'term_id' => $data['term_id']],
                ['created_by' => $request->user()->id, 'status' => 'draft']
            );
            abort_unless(in_array($submission->status, ['draft', 'in_progress'], true), 422, 'The official result submission for this subject is already locked. Reopen it before adding CBT scores.');
            $assessment = CbtAssessment::create([
                ...collect($data)->except('question_ids')->toArray(),
                'school_id' => $schoolId,
                'created_by' => $request->user()->id,
                'assessment_structure_id' => $structure->id,
                'result_submission_id' => $submission->id,
                'total_marks' => $totalMarks,
                'status' => 'draft',
                'results_status' => 'draft',
            ]);

            foreach ($questions->values() as $index => $question) {
                CbtAssessmentQuestion::create([
                    'cbt_assessment_id' => $assessment->id,
                    'cbt_question_id' => $question->id,
                    'display_order' => $index + 1,
                    'marks' => $question->marks,
                    'question_snapshot' => $question->question,
                    'options_snapshot' => $question->options,
                    'correct_answer_snapshot' => $question->correct_answer,
                ]);
            }

            return $assessment;
        });

        return response()->json(['data' => $this->adminAssessment($assessment->fresh()), 'message' => 'CBT assessment saved as draft.'], 201);
    }

    public function show(Request $request, CbtAssessment $cbtAssessment)
    {
        abort_unless((int) $cbtAssessment->school_id === $this->requireSchool($request), 404);
        return response()->json(['data' => $this->adminAssessment($cbtAssessment)]);
    }

    public function publish(Request $request, CbtAssessment $cbtAssessment)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $cbtAssessment->school_id === $schoolId, 404);
        abort_unless($this->isAcademicLeader($request, $schoolId), 403, 'Only academic leadership can publish CBT assessments.');
        abort_unless($cbtAssessment->questions()->exists(), 422, 'Add at least one question before publishing the assessment.');
        $cbtAssessment->update(['status' => 'published']);
        return response()->json(['data' => $this->adminAssessment($cbtAssessment->fresh()), 'message' => 'CBT assessment published.']);
    }

    public function close(Request $request, CbtAssessment $cbtAssessment)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $cbtAssessment->school_id === $schoolId, 404);
        abort_unless($this->isAcademicLeader($request, $schoolId), 403, 'Only academic leadership can close CBT assessments.');
        $cbtAssessment->update(['status' => 'closed']);
        return response()->json(['data' => $cbtAssessment->fresh(), 'message' => 'CBT assessment closed.']);
    }

    public function availableForStudent(Request $request)
    {
        [$schoolId, $enrollment] = $this->studentEnrollment($request);
        $now = now();
        $assessments = CbtAssessment::where('school_id', $schoolId)
            ->where('class_id', $enrollment->class_id)
            ->where('status', 'published')
            ->where(function ($query) use ($now) { $query->whereNull('available_from')->orWhere('available_from', '<=', $now); })
            ->where(function ($query) use ($now) { $query->whereNull('available_until')->orWhere('available_until', '>=', $now); })
            ->withCount(['questions'])
            ->with(['subject:id,name', 'academicSession:id,name', 'term:id,name'])
            ->get()
            ->map(function (CbtAssessment $assessment) use ($enrollment) {
                $latest = $assessment->attempts()->where('student_enrollment_id', $enrollment->id)->latest('attempt_number')->first();
                return [...$assessment->toArray(), 'attempt_status' => $latest?->status, 'attempt_id' => $latest?->id];
            });

        return response()->json(['data' => $assessments]);
    }

    public function startForStudent(Request $request, CbtAssessment $cbtAssessment)
    {
        [$schoolId, $enrollment] = $this->studentEnrollment($request);
        abort_unless((int) $cbtAssessment->school_id === $schoolId && (int) $cbtAssessment->class_id === (int) $enrollment->class_id, 404);
        abort_unless($cbtAssessment->status === 'published', 422, 'This assessment is not open.');
        $now = now();
        abort_unless((!$cbtAssessment->available_from || $cbtAssessment->available_from <= $now) && (!$cbtAssessment->available_until || $cbtAssessment->available_until >= $now), 422, 'This assessment is outside its available time window.');

        $latest = CbtAttempt::where('cbt_assessment_id', $cbtAssessment->id)->where('student_enrollment_id', $enrollment->id)->latest('attempt_number')->first();
        if ($latest && $latest->status === 'in_progress') {
            if ($latest->expires_at && now()->greaterThanOrEqualTo($latest->expires_at)) {
                return $this->submitForStudent($request, $latest, true);
            }
            return response()->json(['data' => $this->studentAttempt($latest)]);
        }

        $attemptNumber = ($latest?->attempt_number ?? 0) + 1;
        abort_unless($attemptNumber <= $cbtAssessment->max_attempts, 422, 'You have used all attempts for this assessment.');
        $expiresAt = $now->copy()->addMinutes($cbtAssessment->duration_minutes);
        if ($cbtAssessment->available_until && $cbtAssessment->available_until->lt($expiresAt)) $expiresAt = $cbtAssessment->available_until;
        $attempt = CbtAttempt::create([
            'school_id' => $schoolId,
            'cbt_assessment_id' => $cbtAssessment->id,
            'student_enrollment_id' => $enrollment->id,
            'attempt_number' => $attemptNumber,
            'started_at' => $now,
            'expires_at' => $expiresAt,
            'status' => 'in_progress',
            'total_questions' => $cbtAssessment->questions()->count(),
        ]);

        return response()->json(['data' => $this->studentAttempt($attempt)]);
    }

    public function answer(Request $request, CbtAttempt $cbtAttempt)
    {
        $this->assertStudentAttempt($request, $cbtAttempt);
        abort_unless($cbtAttempt->status === 'in_progress', 422, 'This attempt is no longer open.');
        if ($cbtAttempt->expires_at && now()->greaterThanOrEqualTo($cbtAttempt->expires_at)) return $this->submitForStudent($request, $cbtAttempt, true);
        $data = $request->validate(['assessment_question_id' => ['required', 'integer'], 'selected_answer' => ['nullable', 'string', 'max:500']]);
        $question = $cbtAttempt->assessment->questions()->whereKey($data['assessment_question_id'])->firstOrFail();
        $cbtAttempt->answers()->updateOrCreate(['cbt_assessment_question_id' => $question->id], ['selected_answer' => $data['selected_answer'], 'answered_at' => now()]);
        return response()->json(['message' => 'Answer saved.', 'data' => ['assessment_question_id' => $question->id]]);
    }

    public function submit(Request $request, CbtAttempt $cbtAttempt)
    {
        return $this->submitForStudent($request, $cbtAttempt, false);
    }

    public function attempts(Request $request, CbtAssessment $cbtAssessment)
    {
        abort_unless((int) $cbtAssessment->school_id === $this->requireSchool($request), 404);
        return response()->json(['data' => $cbtAssessment->attempts()->with(['enrollment.student:id,first_name,last_name,admission_number'])->latest()->paginate(50)]);
    }

    public function reviewResults(Request $request, CbtAssessment $cbtAssessment)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $cbtAssessment->school_id === $schoolId, 404);
        abort_unless($this->isAcademicLeader($request, $schoolId), 403, 'Only academic leadership can send CBT results for official review.');
        $submission = $cbtAssessment->resultSubmission;
        abort_unless($submission, 422, 'This CBT assessment is not linked to an official result submission.');
        $submission = $this->submissionService->submit($submission);
        $cbtAssessment->update(['results_status' => 'submitted', 'results_reviewed_by' => $request->user()->id, 'results_reviewed_at' => now(), 'review_note' => $request->input('review_note')]);
        return response()->json(['data' => $cbtAssessment->fresh(), 'message' => 'CBT scores sent to the official Results Management review queue.']);
    }

    public function publishResults(Request $request, CbtAssessment $cbtAssessment)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $cbtAssessment->school_id === $schoolId, 404);
        abort_unless($this->isAcademicLeader($request, $schoolId), 403, 'Only academic leadership can publish CBT results.');
        $submission = $cbtAssessment->resultSubmission;
        abort_unless($submission && $submission->status === 'approved', 422, 'Approve the official result submission in Results Management before publishing the final result.');
        $this->submissionService->publish($submission, $request->user()->id);
        $cbtAssessment->update(['results_status' => 'published', 'results_published_at' => now()]);
        return response()->json(['data' => $cbtAssessment->fresh(), 'message' => 'Official final results published. Parents can view them through the published report card.']);
    }

    public function studentResult(Request $request, CbtAttempt $cbtAttempt)
    {
        $this->assertStudentAttempt($request, $cbtAttempt);
        abort_unless($cbtAttempt->status === 'submitted', 422, 'This attempt has not been submitted.');
        $assessment = $cbtAttempt->assessment;
        abort_unless($assessment->results_status === 'published', 403, 'Results have not been published yet.');
        abort_unless(Result::where('student_enrollment_id', $cbtAttempt->student_enrollment_id)->where('subject_id', $assessment->subject_id)->where('academic_session_id', $assessment->academic_session_id)->where('term_id', $assessment->term_id)->where('is_published', true)->exists(), 403, 'The official subject result has not been published yet.');
        abort_unless(ReportCard::where('student_enrollment_id', $cbtAttempt->student_enrollment_id)->where('academic_session_id', $assessment->academic_session_id)->where('term_id', $assessment->term_id)->where('is_published', true)->exists(), 403, 'The final report card has not been published yet.');
        return response()->json(['data' => $cbtAttempt->load('assessment:id,title,subject_id,total_marks,results_status')]);
    }

    private function syncAttemptToOfficialResult(CbtAttempt $attempt): void
    {
        $assessment = $attempt->assessment()->with(['assessmentStructure', 'resultSubmission'])->firstOrFail();
        abort_unless($assessment->assessment_structure_id && $assessment->result_submission_id, 422, 'This CBT assessment is not linked to official result computation.');
        $this->submissionService->start($assessment->resultSubmission);
        $this->resultEntryService->saveStudentResult([
            'student_enrollment_id' => $attempt->student_enrollment_id,
            'subject_id' => $assessment->subject_id,
            'academic_session_id' => $assessment->academic_session_id,
            'term_id' => $assessment->term_id,
            'school_id' => $attempt->school_id,
            'result_submission_id' => $assessment->result_submission_id,
            'components' => [[
                'assessment_structure_id' => $assessment->assessment_structure_id,
                'score' => (float) $attempt->score,
            ]],
        ]);
    }

    private function isAcademicLeader(Request $request, int $schoolId): bool
    {
        return collect(['proprietor', 'principal', 'vice_principal_academic', 'primary_headmaster', 'secondary_principal'])
            ->contains(fn (string $role) => $request->user()->hasRole($role, $schoolId));
    }

    private function studentEnrollment(Request $request): array
    {
        $schoolId = $this->requireSchool($request);
        $student = Student::where('school_id', $schoolId)->where('user_id', $request->user()->id)->firstOrFail();
        $enrollment = StudentEnrollment::where('school_id', $schoolId)->where('student_id', $student->id)->where('status', 'active')->latest()->first();
        abort_unless($enrollment, 409, 'No active student enrollment found.');
        return [$schoolId, $enrollment];
    }

    private function assertStudentAttempt(Request $request, CbtAttempt $attempt): void
    {
        [$schoolId, $enrollment] = $this->studentEnrollment($request);
        abort_unless((int) $attempt->school_id === $schoolId && (int) $attempt->student_enrollment_id === (int) $enrollment->id, 404);
    }

    private function submitForStudent(Request $request, CbtAttempt $attempt, bool $expired)
    {
        $this->assertStudentAttempt($request, $attempt);
        if ($attempt->status === 'submitted') return response()->json(['data' => $attempt->fresh(), 'message' => 'Attempt already submitted.']);
        $attempt->load(['assessment.questions', 'answers']);
        $score = 0; $correct = 0;
        foreach ($attempt->assessment->questions as $question) {
            $answer = $attempt->answers->firstWhere('cbt_assessment_question_id', $question->id);
            $selected = $answer?->selected_answer;
            $isCorrect = $selected !== null && $selected === $question->correct_answer_snapshot;
            $awarded = $isCorrect ? (float) $question->marks : 0;
            if ($isCorrect) { $correct++; $score += $awarded; }
            $attempt->answers()->updateOrCreate(['cbt_assessment_question_id' => $question->id], ['selected_answer' => $selected, 'is_correct' => $isCorrect, 'awarded_marks' => $awarded, 'answered_at' => $answer?->answered_at ?? now()]);
        }
        $totalMarks = max(1, (float) $attempt->assessment->total_marks);
        $attempt->update(['status' => 'submitted', 'submitted_at' => now(), 'correct_answers' => $correct, 'total_questions' => $attempt->assessment->questions->count(), 'score' => $score, 'percentage' => round(($score / $totalMarks) * 100, 2)]);
        $this->syncAttemptToOfficialResult($attempt->fresh());
        return response()->json(['data' => $attempt->fresh(), 'message' => $expired ? 'Time expired. Your answers were submitted automatically.' : 'Test submitted successfully.']);
    }

    private function studentAttempt(CbtAttempt $attempt): array
    {
        $attempt->load(['assessment:id,title,instructions,duration_minutes,total_marks,pass_mark', 'assessment.questions:id,cbt_assessment_id,display_order,marks,question_snapshot,options_snapshot', 'answers:id,cbt_attempt_id,cbt_assessment_question_id,selected_answer']);
        $attempt->assessment->setRelation('questions', $attempt->assessment->questions->map(fn ($question) => ['id' => $question->id, 'display_order' => $question->display_order, 'marks' => $question->marks, 'question' => $question->question_snapshot, 'options' => $question->options_snapshot]));
        return $attempt->toArray();
    }

    private function adminAssessment(CbtAssessment $assessment): array
    {
        return $assessment->load(['class:id,name', 'subject:id,name', 'academicSession:id,name', 'term:id,name', 'questions:id,cbt_assessment_id,cbt_question_id,display_order,marks'])->toArray();
    }
}
