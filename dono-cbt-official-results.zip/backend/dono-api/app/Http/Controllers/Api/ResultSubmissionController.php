<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ResultSubmission;
use App\Models\CbtAssessment;
use App\Services\Academic\ResultSubmissionService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ResultSubmissionController extends Controller
{
    public function __construct(
        protected ResultSubmissionService $submissionService
    ) {
    }

    private function scoped(Request $request, ResultSubmission $submission): ResultSubmission
    {
        abort_unless((int) $submission->school_id === $this->requireSchool($request), 404, 'Result submission not found.');
        return $submission->load(['class:id,name', 'subject:id,name', 'academicSession:id,name', 'term:id,name', 'creator:id,name', 'approver:id,name']);
    }

    public function index(Request $request): JsonResponse
    {
        return response()->json([
            'data' => ResultSubmission::where('school_id', $this->requireSchool($request))
                ->with(['class:id,name', 'subject:id,name', 'academicSession:id,name', 'term:id,name', 'creator:id,name', 'approver:id,name'])
                ->latest()
                ->paginate(min(max($request->integer('per_page', 30), 1), 100)),
        ]);
    }

    /**
     * Create a new result submission.
     */
    public function createSubmission(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'class_id' => ['required', 'integer', 'exists:classes,id'],
            'subject_id' => ['required', 'integer', 'exists:subjects,id'],
            'academic_session_id' => ['required', 'integer', 'exists:academic_sessions,id'],
            'term_id' => ['required', 'integer', 'exists:terms,id'],
        ]);

        $submission = $this->submissionService->create([
            ...$validated,
            'school_id' => $this->requireSchool($request),
            'created_by' => $request->user()->id,
        ]);

        $results = $this->submissionService
            ->createDraftResults($submission);

        return response()->json([
            'success' => true,
            'message' => 'Result submission created successfully.',
            'submission' => $submission,
            'results' => $results,
        ], 201);
    }

    /**
     * Load an existing submission.
     */
    public function loadSubmission(Request $request, ResultSubmission $submission): JsonResponse
    {
        return response()->json([
            'success' => true,
            'submission' => $this->scoped($request, $submission),
        ]);
    }

    /**
     * Autosave.
     */
    public function autoSave(Request $request): JsonResponse
    {
        return response()->json([
            'success' => true,
            'message' => 'Autosave implementation comes next.',
        ]);
    }

    /**
     * Submit for approval.
     */
    public function submit(Request $request, ResultSubmission $submission): JsonResponse
    {
        $submission = $this->scoped($request, $submission);
        abort_unless(in_array($submission->status, ['draft', 'in_progress'], true), 422, 'Only draft or in-progress submissions can be submitted.');
        $updated = $this->submissionService->submit($submission);

        return response()->json(['success' => true, 'message' => 'Result submission sent for approval.', 'submission' => $this->scoped($request, $updated)]);
    }

    /**
     * Approve submission.
     */
    public function approve(
        Request $request,
        ResultSubmission $submission
    ): JsonResponse {
        $submission = $this->scoped($request, $submission);
        abort_unless($submission->status === 'submitted', 422, 'Only submitted results can be approved.');
        $submission = $this->submissionService->approve($submission, $request->user()->id, $request->input('approval_note'));
        CbtAssessment::where('result_submission_id', $submission->id)->update(['results_status' => 'approved', 'results_reviewed_by' => $request->user()->id, 'results_reviewed_at' => now()]);

        return response()->json(['success' => true, 'message' => 'Result submission approved.', 'submission' => $this->scoped($request, $submission)]);
    }

    /**
     * Publish results.
     */
    public function publish(Request $request, ResultSubmission $submission): JsonResponse
    {
        $submission = $this->scoped($request, $submission);
        abort_unless(in_array($submission->status, ['approved', 'published'], true), 422, 'Only approved results can be published.');
        $updated = $this->submissionService->publish($submission, $request->user()->id);
        CbtAssessment::where('result_submission_id', $updated->id)->update(['results_status' => 'published', 'results_published_at' => now()]);

        return response()->json(['success' => true, 'message' => 'Results published to student and parent portals.', 'submission' => $this->scoped($request, $updated)]);
    }

    /**
     * Reopen submission.
     */
    public function reopen(Request $request, ResultSubmission $submission): JsonResponse
    {
        $submission = $this->scoped($request, $submission);
        abort_unless(in_array($submission->status, ['submitted', 'approved', 'published'], true), 422, 'This submission cannot be reopened.');
        $updated = $this->submissionService->reopen($submission);

        return response()->json(['success' => true, 'message' => 'Result submission reopened for correction.', 'submission' => $this->scoped($request, $updated)]);
    }

    /**
     * Cancel submission.
     */
    public function cancel(Request $request, ResultSubmission $submission): JsonResponse
    {
        $this->submissionService->cancel($this->scoped($request, $submission));

        return response()->json(['success' => true, 'message' => 'Submission cancelled successfully.']);
    }
}
