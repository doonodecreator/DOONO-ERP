import "./button.css";

export default function Button({ variant = "primary", size = "md", loading = false, children, type = "button", disabled = false, ...props }) {
  return <button type={type} className={`ui-button ui-button-${variant} ui-button-${size}`} disabled={loading || disabled} {...props}>{loading ? "Saving..." : children}</button>;
}
