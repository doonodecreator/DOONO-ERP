export function arrayFromResponse(response) {
  const candidates = [
    response?.data?.data?.data,
    response?.data?.data,
    response?.data,
    response?.data?.items,
    response?.items,
    response,
  ];

  return candidates.find((candidate) => Array.isArray(candidate)) || [];
}
