<?php

namespace App\Services;

use App\Models\AppNotification;
use App\Models\Communication;
use Illuminate\Support\Facades\DB;

class NotificationService
{
    public function notifyCommunication(Communication $communication): int
    {
        if (!$communication->is_published || !$communication->school_id) {
            return 0;
        }

        $recipientIds = $this->recipientIds($communication);
        $organizationId = $communication->school?->organization_id
            ?? DB::table('schools')->where('id', $communication->school_id)->value('organization_id');
        $created = 0;

        foreach ($recipientIds as $userId) {
            $created += DB::table('app_notifications')->insertOrIgnore([
                'organization_id' => $organizationId,
                'school_id' => $communication->school_id,
                'user_id' => $userId,
                'type' => $communication->type ?: 'notice',
                'priority' => 'normal',
                'title' => $communication->subject ?: 'School notice',
                'body' => $communication->body,
                'source_type' => Communication::class,
                'source_id' => $communication->id,
                'dedupe_key' => "communication:{$communication->id}:user:{$userId}",
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }

        return $created;
    }

    public function markRead(AppNotification $notification, int $userId): AppNotification
    {
        if (!$notification->read_at) {
            $notification->forceFill(['read_at' => now()])->save();
        }

        return $notification;
    }

    private function recipientIds(Communication $communication): array
    {
        $base = DB::table('user_roles')
            ->join('roles', 'roles.id', '=', 'user_roles.role_id')
            ->where('user_roles.school_id', $communication->school_id)
            ->when($communication->recipient_id, fn ($query) => $query->where('user_roles.user_id', $communication->recipient_id))
            ->when(!$communication->recipient_id && $communication->audience !== 'all', function ($query) use ($communication) {
                if ($communication->audience === 'parents') {
                    $query->where('roles.slug', 'parent');
                } elseif ($communication->audience === 'students') {
                    $query->where('roles.slug', 'student');
                } else {
                    $query->whereNotIn('roles.slug', ['parent', 'student']);
                }
            })
            ->distinct()
            ->pluck('user_roles.user_id');

        return $base->map(fn ($id) => (int) $id)->values()->all();
    }
}
