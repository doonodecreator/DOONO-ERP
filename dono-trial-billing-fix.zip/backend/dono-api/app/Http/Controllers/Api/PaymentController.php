<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\School;
use App\Models\SchoolSubscription;
use App\Models\SubscriptionPlan;
use App\Models\SystemSetting;
use App\Services\CurrentContextService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class PaymentController extends Controller
{
    public function __construct(
        private readonly CurrentContextService $context
    ) {
    }

    public function initialize(Request $request)
    {
        $request->validate([
            'student_id' => 'required|exists:students,id',
            'amount' => 'required|numeric|min:100',
            'fee_category_id' => 'required|exists:fee_categories,id',
        ]);

        $student = DB::table('students')->where('id', $request->student_id)->first();
        if (!$student) return response()->json(['success' => false, 'message' => 'Student not found.'], 404);

        $schoolSettings = DB::table('school_settings')->where('school_id', $student->school_id)->first();
        $secretKey = $schoolSettings->paystack_secret_key ?? config('services.paystack.secret_key');
        $subaccountCode = $schoolSettings->paystack_subaccount_code ?? null;

        if (!$secretKey) return response()->json(['success' => false, 'message' => 'Payment gateway not configured.'], 422);

        $reference = 'DONO_FEE_' . strtoupper(uniqid());
        $callbackUrl = rtrim((string) (config('app.frontend_url') ?: $request->getSchemeAndHttpHost()), '/') . '/fees-payments?reference=' . $reference;

        $payload = [
            'email' => $student->email ?? 'student@donoerp.com',
            'amount' => $request->amount * 100,
            'reference' => $reference,
            'callback_url' => $callbackUrl,
            'metadata' => [
                'payment_type' => 'school_fee',
                'student_id' => $student->id,
                'school_id' => $student->school_id,
                'fee_category_id' => $request->fee_category_id,
            ],
        ];

        if ($subaccountCode) $payload['subaccount'] = $subaccountCode;

        $response = Http::withToken($secretKey)->post('https://api.paystack.co/transaction/initialize', $payload);

        if ($response->successful()) {
            $data = $response->json()['data'];
            DB::table('fee_payments')->insert([
                'school_id' => $student->school_id,
                'student_id' => $student->id,
                'fee_category_id' => $request->fee_category_id,
                'amount' => $request->amount,
                'reference' => $reference,
                'status' => 'pending',
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return response()->json(['success' => true, 'data' => ['authorization_url' => $data['authorization_url'], 'reference' => $reference]]);
        }

        return response()->json(['success' => false, 'message' => 'Failed to initialize payment.'], 400);
    }

    public function verify($reference)
    {
        $payment = DB::table('fee_payments')->where('reference', $reference)->first();
        if (!$payment) return response()->json(['success' => false, 'message' => 'Payment record not found.'], 404);

        $schoolSettings = DB::table('school_settings')->where('school_id', $payment->school_id)->first();
        $secretKey = $schoolSettings->paystack_secret_key ?? config('services.paystack.secret_key');

        if (!$secretKey) return response()->json(['success' => false, 'message' => 'Payment gateway not configured.'], 422);

        $response = Http::withToken($secretKey)->get("https://api.paystack.co/transaction/verify/{$reference}");

        if ($response->successful()) {
            $data = $response->json()['data'];
            if (($data['status'] ?? null) === 'success') {
                if ((int) ($data['amount'] ?? 0) !== (int) round((float) $payment->amount * 100)) {
                    return response()->json(['success' => false, 'message' => 'Payment amount does not match the pending invoice.'], 422);
                }

                DB::transaction(function () use ($payment, $data, $reference) {
                    $locked = DB::table('fee_payments')->where('reference', $reference)->lockForUpdate()->first();
                    if ($locked?->status === 'success') return;
                    DB::table('fee_payments')->where('reference', $reference)->update(['status' => 'success', 'updated_at' => now()]);
                    DB::table('payment_receipts')->updateOrInsert(['reference' => $reference], [
                        'school_id' => $payment->school_id,
                        'student_id' => $payment->student_id,
                        'amount' => $data['amount'] / 100,
                        'fee_category_id' => $payment->fee_category_id,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                });
                return response()->json(['success' => true, 'message' => 'Payment verified.', 'data' => $data]);
            }
        }
        return response()->json(['success' => false, 'message' => 'Verification failed.'], 400);
    }

    public function initializeSubscription(Request $request)
    {
        $data = $request->validate([
            'subscription_plan_id' => ['required', 'integer', 'exists:subscription_plans,id'],
            'billing_cycle' => ['required', 'in:monthly,quarterly,half_yearly,yearly'],
        ]);

        $user = $request->user();
        $schoolId = $this->context->currentSchool($user)?->id;
        $school = $schoolId ? School::find($schoolId) : null;
        if (!$school) return response()->json(['success' => false, 'message' => 'Select an active school before upgrading.'], 422);

        $platformSettings = SystemSetting::first();
        if ($platformSettings && !$platformSettings->enforce_subscriptions) {
            return response()->json(['success' => false, 'message' => 'All schools currently have free platform access. Payment will be required when the Software Owner enables subscription enforcement.'], 422);
        }

        $plan = SubscriptionPlan::whereKey($data['subscription_plan_id'])
            ->where('is_active', true)
            ->first();
        if (!$plan) return response()->json(['success' => false, 'message' => 'The selected subscription plan is unavailable.'], 422);

        $subscription = SchoolSubscription::with('subscriptionPlan')
            ->where('school_id', $school->id)
            ->where('is_current', true)
            ->latest()
            ->first();
        if ($subscription?->is_exempt) return response()->json(['success' => false, 'message' => 'This school has free access and does not need to pay.'], 422);
        if ($subscription && $subscription->discount_percentage >= 100 && $subscription->hasActiveDiscount()) {
            return response()->json(['success' => false, 'message' => 'This school has a free-access period and does not need to pay yet.'], 422);
        }

        $baseAmount = match ($data['billing_cycle']) {
            'monthly' => (float) $plan->monthly_price,
            'quarterly' => (float) $plan->quarterly_price,
            'half_yearly' => (float) $plan->half_yearly_price,
            default => (float) $plan->yearly_price,
        };
        $amount = $subscription
            ? $subscription->discountedPrice($baseAmount)
            : $baseAmount;
        if ($amount <= 0) return response()->json(['success' => false, 'message' => 'No amount is due for the selected plan.'], 422);

        $pending = DB::table('payment_transactions')
            ->where('school_id', $school->id)
            ->where('status', 'pending')
            ->where('created_at', '>=', now()->subHours(24))
            ->latest()
            ->first();
        if ($pending) {
            $pendingPayload = is_string($pending->gateway_response) ? json_decode($pending->gateway_response, true) : (array) $pending->gateway_response;
            if (!empty($pendingPayload['authorization_url'])) {
                return response()->json(['success' => true, 'message' => 'A subscription payment is already pending. Resume the existing checkout.', 'data' => ['authorization_url' => $pendingPayload['authorization_url'], 'reference' => $pending->reference, 'resumed' => true]]);
            }
            return response()->json(['success' => false, 'message' => 'A subscription payment is already pending. Verify it before starting another payment.', 'reference' => $pending->reference], 409);
        }

        $secretKey = config('services.paystack.secret_key');
        if (!$secretKey) return response()->json(['success' => false, 'message' => 'Paystack is not configured on the server.'], 422);

        if (!$subscription) {
            $subscription = SchoolSubscription::create([
                'school_id' => $school->id,
                'subscription_plan_id' => $plan->id,
                'billing_cycle' => $data['billing_cycle'],
                'status' => 'pending',
                'amount_paid' => 0,
                'currency' => strtoupper((string) ($plan->currency ?: 'NGN')),
                'is_current' => true,
                'is_exempt' => false,
            ]);
        }

        $reference = 'DONO_SUB_' . strtoupper(uniqid());
        $callbackUrl = rtrim((string) (config('app.frontend_url') ?: $request->getSchemeAndHttpHost()), '/') . '/subscription-payment?reference=' . $reference;
        $currency = strtoupper((string) ($plan->currency ?: 'NGN'));
        $payload = [
            'email' => strtolower(trim($user->email)),
            'amount' => (int) round($amount * 100),
            'currency' => $currency,
            'reference' => $reference,
            'callback_url' => $callbackUrl,
            'metadata' => [
                'payment_type' => 'subscription',
                'school_id' => $school->id,
                'school_subscription_id' => $subscription->id,
                'subscription_plan_id' => $plan->id,
                'billing_cycle' => $data['billing_cycle'],
            ],
        ];

        $response = Http::withToken($secretKey)->post('https://api.paystack.co/transaction/initialize', $payload);
        if (!$response->successful()) return response()->json(['success' => false, 'message' => 'Paystack could not initialize the subscription payment.'], 400);

        $gatewayData = $response->json()['data'] ?? [];
        DB::table('payment_transactions')->insert([
            'school_id' => $school->id,
            'school_subscription_id' => $subscription->id,
            'gateway' => 'paystack',
            'reference' => $reference,
            'amount' => $amount,
            'currency' => $currency,
            'billing_cycle' => $data['billing_cycle'],
            'status' => 'pending',
            'gateway_response' => json_encode([
                'authorization_url' => $gatewayData['authorization_url'] ?? null,
                'subscription_plan_id' => $plan->id,
                'billing_cycle' => $data['billing_cycle'],
            ]),
            'created_at' => now(),
            'updated_at' => now(),
        ]);
        $subscription->update(['payment_reference' => $reference]);

        return response()->json(['success' => true, 'data' => ['authorization_url' => $gatewayData['authorization_url'] ?? null, 'reference' => $reference]]);
    }

    public function verifySubscription(Request $request, $reference)
    {
        $schoolId = $this->context->currentSchool($request->user())?->id;
        $transaction = DB::table('payment_transactions')->where('reference', $reference)->where('school_id', $schoolId)->first();
        if (!$transaction) return response()->json(['success' => false, 'message' => 'Subscription payment record not found for the active school.'], 404);
        if ($transaction->status === 'successful') return response()->json(['success' => true, 'message' => 'Subscription payment was already verified.', 'data' => ['reference' => $reference, 'status' => 'active']]);

        $subscription = SchoolSubscription::where('school_id', $schoolId)->whereKey($transaction->school_subscription_id)->first();
        if (!$subscription) return response()->json(['success' => false, 'message' => 'Subscription record not found.'], 404);

        $secretKey = config('services.paystack.secret_key');
        $response = Http::withToken($secretKey)->get("https://api.paystack.co/transaction/verify/{$reference}");
        if (!$response->successful()) return response()->json(['success' => false, 'message' => 'Paystack verification could not be completed.'], 502);

        $gatewayData = $response->json()['data'] ?? [];
        if (($gatewayData['status'] ?? null) !== 'success') return response()->json(['success' => false, 'message' => 'Payment has not been confirmed as successful.'], 400);
        if ((int) ($gatewayData['amount'] ?? 0) !== (int) round((float) $transaction->amount * 100)) return response()->json(['success' => false, 'message' => 'Verified amount does not match the pending subscription payment.'], 422);

        $this->activatePaidSubscription($subscription, ((float) $gatewayData['amount']) / 100, $reference, $gatewayData);
        $updatedSubscription = $subscription->fresh();
        $startsAfterTrial = $updatedSubscription?->start_date && $updatedSubscription->start_date->isFuture();
        $message = $startsAfterTrial
            ? 'Payment verified. Your paid subscription will start after the free trial ends on ' . $updatedSubscription->start_date->toDateString() . '.'
            : 'Subscription payment verified and activated.';

        return response()->json(['success' => true, 'message' => $message, 'data' => ['reference' => $reference, 'status' => $updatedSubscription?->status, 'start_date' => $updatedSubscription?->start_date]]);
    }

    public function webhook(Request $request)
    {
        $signature = $request->header('X-Paystack-Signature');
        $secretKey = config('services.paystack.secret_key');
        if (!$signature || !$secretKey || !hash_equals(hash_hmac('sha512', $request->getContent(), $secretKey), $signature)) {
            return response()->json(['success' => false], 401);
        }

        $event = $request->input('event');
        $data = $request->input('data', []);

        if ($event === 'charge.success') {
            $reference = $data['reference'] ?? null;
            $amountPaid = ($data['amount'] ?? 0) / 100;

            if ($reference) {
                $transaction = DB::table('payment_transactions')->where('reference', $reference)->first();
                $subscription = $transaction ? SchoolSubscription::find($transaction->school_subscription_id) : SchoolSubscription::where('payment_reference', $reference)->first();
                if ($subscription && $transaction && $transaction->status !== 'successful' && (int) round((float) $transaction->amount * 100) === (int) ($data['amount'] ?? 0)) {
                    $this->activatePaidSubscription($subscription, $amountPaid, $reference, $data);
                }

                $payment = DB::table('fee_payments')->where('reference', $reference)->first();
                if ($payment && $payment->status !== 'success' && (int) round((float) $payment->amount * 100) === (int) ($data['amount'] ?? 0)) {
                    DB::transaction(function () use ($payment, $data, $reference) {
                        $locked = DB::table('fee_payments')->where('reference', $reference)->lockForUpdate()->first();
                        if ($locked?->status === 'success') return;
                        DB::table('fee_payments')->where('reference', $reference)->update(['status' => 'success', 'updated_at' => now()]);
                        DB::table('payment_receipts')->updateOrInsert(['reference' => $reference], [
                            'school_id' => $payment->school_id,
                            'student_id' => $payment->student_id,
                            'amount' => ($data['amount'] ?? 0) / 100,
                            'fee_category_id' => $payment->fee_category_id,
                            'created_at' => now(),
                            'updated_at' => now(),
                        ]);
                    });
                }
            }
        }

        return response()->json(['status' => 'success']);
    }

    private function activatePaidSubscription(SchoolSubscription $subscription, float $amountPaid, string $reference, array $gatewayData = []): void
    {
        DB::transaction(function () use ($subscription, $amountPaid, $reference, $gatewayData) {
            $transaction = DB::table('payment_transactions')->where('reference', $reference)->lockForUpdate()->first();
            if ($transaction?->status === 'successful') return;

            $stored = $transaction && is_string($transaction->gateway_response) ? json_decode($transaction->gateway_response, true) : [];
            $planId = $stored['subscription_plan_id'] ?? ($gatewayData['metadata']['subscription_plan_id'] ?? null);
            $billingCycle = $stored['billing_cycle'] ?? ($gatewayData['metadata']['billing_cycle'] ?? $subscription->billing_cycle);

            $subscription->refresh();
            if ($planId) $subscription->subscription_plan_id = $planId;
            $subscription->billing_cycle = $billingCycle;

            $trialIsActive = $subscription->status === 'trial'
                && $subscription->trial_ends_at
                && now()->lessThanOrEqualTo($subscription->trial_ends_at->copy()->endOfDay());

            if ($trialIsActive) {
                // The paid period starts the day after the free trial ends.
                $startDate = $subscription->trial_ends_at->copy()->addDay()->startOfDay();
            } elseif ($subscription->expiry_date && $subscription->expiry_date->isFuture()) {
                // A renewal extends an already active paid period instead of overlapping it.
                $startDate = $subscription->expiry_date->copy()->startOfDay();
            } else {
                $startDate = now()->startOfDay();
            }

            $expiryDate = match ($subscription->billing_cycle) {
                'monthly' => $startDate->copy()->addMonth(),
                'quarterly' => $startDate->copy()->addMonths(3),
                'half_yearly' => $startDate->copy()->addMonths(6),
                default => $startDate->copy()->addYear(),
            };

            $subscription->update([
                'status' => 'active',
                'is_current' => true,
                'start_date' => $startDate,
                'expiry_date' => $expiryDate,
                'next_billing_date' => $expiryDate,
                'amount_paid' => $amountPaid,
                'payment_reference' => $reference,
            ]);

            if ($transaction) {
                DB::table('payment_transactions')->where('reference', $reference)->update([
                    'status' => 'successful',
                    'paid_at' => now(),
                    'gateway_transaction_id' => $gatewayData['id'] ?? null,
                    'gateway_response' => json_encode($gatewayData ?: $stored),
                    'updated_at' => now(),
                ]);
            }
        });
    }
}
