<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreSubscriptionPlanRequest;
use App\Http\Requests\UpdateSubscriptionPlanRequest;
use App\Http\Resources\SubscriptionPlanResource;
use App\Models\SubscriptionPlan;
use App\Services\ActivityLogService;

class SubscriptionPlanController extends Controller
{
    public function index()
    {
        return SubscriptionPlanResource::collection(
            SubscriptionPlan::latest()->paginate(10)
        );
    }

    public function store(StoreSubscriptionPlanRequest $request)
    {
        $plan = SubscriptionPlan::create($request->validated());

        ActivityLogService::log(
            module: 'subscription_plans',
            action: 'created',
            description: "Subscription plan \"{$plan->name}\" was created.",
            subject: $plan,
            properties: ['plan_id' => $plan->id],
        );

        return (new SubscriptionPlanResource($plan))
            ->response()
            ->setStatusCode(201);
    }

    public function show(SubscriptionPlan $subscriptionPlan)
    {
        return new SubscriptionPlanResource($subscriptionPlan);
    }

    public function update(
        UpdateSubscriptionPlanRequest $request,
        SubscriptionPlan $subscriptionPlan
    ) {
        $validated = $request->validated();
        $subscriptionPlan->update($validated);

        ActivityLogService::log(
            module: 'subscription_plans',
            action: 'updated',
            description: "Subscription plan \"{$subscriptionPlan->name}\" was updated.",
            subject: $subscriptionPlan,
            properties: ['changed_fields' => array_keys($validated)],
        );

        return new SubscriptionPlanResource($subscriptionPlan);
    }

    public function destroy(SubscriptionPlan $subscriptionPlan)
    {
        $planId = $subscriptionPlan->id;
        $planName = $subscriptionPlan->name;
        $subscriptionPlan->delete();

        ActivityLogService::log(
            module: 'subscription_plans',
            action: 'deleted',
            description: "Subscription plan \"{$planName}\" was deleted.",
            properties: ['plan_id' => $planId],
        );

        return response()->json([
            'message' => 'Subscription plan deleted successfully.'
        ]);
    }
}
