import { useState } from "react";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";
import { useNavigate, useSearchParams } from "react-router-dom";
import Footer from "../components/layout/Footer";

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const returnTo = searchParams.get("returnTo");
  const invitedEmail = searchParams.get("email") || "";

  const [email, setEmail] = useState(invitedEmail);
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();

    setLoading(true);
    setError("");

    try {
      const response = await api.post("/login", {
        email: email.trim().toLowerCase(),
        password,
      });
      await login(response.data.token);
      if (returnTo) {
        navigate(returnTo, { replace: true });
      }
      // Otherwise App.jsx reacts to isAuthenticated / onboardingStep changing
      // and renders the right screen automatically.
    } catch (err) {
      const code = err?.response?.data?.code;
      if (code === "EMAIL_VERIFICATION_REQUIRED") {
        navigate(`/verify-email?email=${encodeURIComponent(err?.response?.data?.email || email)}`);
        return;
      }
      setError(err.message || "Invalid email or password.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        background: "#eef2ff",
      }}
    >
      <form
        onSubmit={handleSubmit}
        style={{
          width: 380,
          background: "#fff",
          padding: 40,
          borderRadius: 20,
          boxShadow: "0 20px 40px rgba(0,0,0,.08)",
        }}
      >
        <h1 style={{ textAlign: "center", color: "#1e3a8a" }}>
          DOONO De Creator ERP
        </h1>

        <p style={{ textAlign: "center", color: "#64748b", marginBottom: 30 }}>
          Sign in to continue
        </p>

        {returnTo && (
          <p style={{ color: "#475569", background: "#eef2ff", padding: 12, borderRadius: 10, fontSize: 13, marginBottom: 16 }}>
            This sign-in is for an existing DOONO account. After successful login, you will return to the invitation and activate the school role. If this is your first DOONO account, go back and choose <strong>Create Account and Accept Role</strong> instead.
          </p>
        )}

        {error && <p style={{ color: "red" }}>{error}</p>}

        <input
          type="email"
          placeholder="Email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          style={{ width: "100%", padding: 12, marginBottom: 15 }}
        />

        <input
          type="password"
          placeholder="Password"
          autoComplete="current-password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          style={{ width: "100%", padding: 12, marginBottom: 20 }}
        />

        <button
          type="submit"
          style={{
            width: "100%",
            padding: 12,
            background: "#1e40af",
            color: "#fff",
            border: "none",
          }}
        >
          {loading ? "Signing In..." : "Login"}
        </button>

        <button type="button" onClick={() => navigate(`/forgot-password?email=${encodeURIComponent(email)}`)} style={{ width: "100%", marginTop: 14, background: "transparent", border: "none", color: "#1e40af", textDecoration: "underline", cursor: "pointer" }}>
          Forgot password?
        </button>
      </form>
      <Footer theme="light" />
    </div>
  );
}
