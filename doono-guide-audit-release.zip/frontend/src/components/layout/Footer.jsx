import "./Footer.css";

export default function Footer({ theme = "light" }) {
  const year = new Date().getFullYear();

  return (
    <footer className={`dono-footer dono-footer-${theme}`}>
      <div className="dono-footer-inner">
        <div className="dono-footer-brand">
          <strong>DOONO De Creator ERP</strong>
          <span>School operations, simplified.</span>
        </div>
        <div className="dono-footer-meta">
          <span>© {year} DOONO De Creator</span>
          <span className="dono-footer-separator" aria-hidden="true">•</span>
          <span>Secure multi-tenant school management</span>
        </div>
      </div>
    </footer>
  );
}
