import { useEffect, useMemo, useState } from "react";
import { getPrimaryRoleSlug } from "../../utils/role";
import { useAuth } from "../../context/AuthContext";

const GUIDE_STEPS = {
  super_admin: [
    ["dashboard", "Start with the platform dashboard", "Review platform health, organizations, subscriptions, and system-wide activity."],
    ["organizations", "Review organizations", "Organizations are the top-level owners of one or more schools. Use this area for platform oversight only."],
    ["subscriptions", "Configure plans and billing", "Create or update subscription plans and review school subscription status. Platform subscription changes remain Software Owner actions."],
    ["email-sms-settings", "Test platform communications", "Use the Local Test Inbox while testing verification, password reset, and platform announcements."],
    ["audit-logs", "Review platform activity", "Use the audit log to trace platform actions without mixing them with a school proprietor's operational history."],
  ],
  organization_owner: [
    ["dashboard", "Understand your organization", "Your organization can own one or more schools. Switch into a school only when you want to manage school operations."],
    ["add-school", "Create your first school", "Set the school identity and country before configuring academic data."],
    ["schools", "Choose a school", "Use My Schools to enter a school context or return to the organization context."],
    ["subscriptions", "Review organization billing", "Subscription status applies to the selected school and should be checked before operational work."],
  ],
  proprietor: [
    ["school-setup", "Complete school setup first", "Follow the setup checklist: academic session, term, divisions, classes, streams, subjects, and key staff."],
    ["role-invitations", "Invite and assign staff", "Invite principals, teachers, finance staff, and other roles. Assign form teachers to a specific class where required."],
    ["timetable", "Build the term timetable", "Create lessons and school events only after sessions, terms, classes, subjects, and staff are available."],
    ["fees", "Configure fees", "Create fee structures by class or student category before collecting payments."],
    ["students", "Create learners and portals", "Enroll students, link parents, and create portal accounts only after confirming the correct school context."],
  ],
  principal: [
    ["students", "Review learners and admissions", "Confirm students and class placements before academic operations begin."],
    ["timetable", "Review the timetable", "Use the timetable for school scheduling and verify that lessons have the correct class, subject, and teacher."],
    ["results", "Manage result workflow", "Teachers enter scores; school leadership reviews, approves, and publishes results according to the workflow."],
    ["communication", "Communicate with the school", "Use school-scoped communication for parents, students, and staff."],
  ],
  vice_principal_academic: [
    ["subjects", "Prepare academic subjects", "Confirm subjects and teacher assignments before timetable and result entry work."],
    ["timetable", "Coordinate the timetable", "Check lesson periods, classes, teachers, and school events for the active term."],
    ["examinations", "Configure examinations", "Define assessments and examination structures before scores are entered."],
    ["results", "Review academic results", "Use the result workflow and publish only when the school approval process is complete."],
  ],
  teacher: [
    ["classes", "Review your classes", "Start by checking the classes and subjects assigned to you. Your data is limited to your school assignments."],
    ["attendance", "Take attendance", "Record attendance for the correct class and date. Unsynced work should be clearly marked when offline support is active."],
    ["assignments", "Create and review assignments", "Publish assignments to a class or stream, then review student submissions from the assignment record."],
    ["cbt", "Build question banks", "Create questions in batches, organize them by subject and section, and submit them for approval."],
  ],
  form_teacher: [
    ["classes", "Open your assigned class", "Your form-teacher dashboard and class list are limited to the class assigned to you."],
    ["attendance", "Manage class attendance", "Record attendance and review learner patterns for your assigned class."],
    ["assignments", "Follow up on assignments", "Publish or monitor work for your class and communicate with parents when needed."],
  ],
  parent: [
    ["dashboard", "Start with My Children", "One parent account can show several children in the same school. Always confirm which child a record belongs to."],
    ["assignments", "Follow assignments", "View published assignments and submission status for the selected child."],
    ["report-cards", "View final results", "Parents see report cards only after the school publishes the final result."],
    ["fees-payments", "Review fees and payments", "Fees are grouped by child so a multi-child family can distinguish each learner's balance."],
  ],
  student: [
    ["timetable", "Open your class timetable", "You see only timetable entries for your class, stream, and school."],
    ["assignments", "Submit assignments", "Open a published assignment, write your response, and check the submission status."],
    ["cbt", "Take CBT assessments", "Only assessments published for your student account can be started."],
    ["results", "Review published results", "Your final results and report card appear after the school publishes them."],
  ],
};

const defaultSteps = [["dashboard", "Welcome to DONO", "Use the menu to open the modules available to your role. The guide will explain the recommended order."]];

export default function DONOGuide({ page, setPage }) {
  const { user, roles, isPlatformAdmin, isOrganizationOwner, school } = useAuth();
  const role = getPrimaryRoleSlug({ roles, isPlatformAdmin, isOrganizationOwner, school });
  const steps = useMemo(() => GUIDE_STEPS[role] || defaultSteps, [role]);
  const storageKey = `dono-guide:${user?.id || "guest"}:${role}:${school?.id || "organization"}`;
  const [open, setOpen] = useState(false);
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    if (!user?.id) return;
    const completed = window.localStorage.getItem(storageKey) === "complete";
    setOpen(!completed);
    setStepIndex(0);
  }, [storageKey, user?.id]);

  function closeGuide() {
    setOpen(false);
  }

  function finishGuide() {
    window.localStorage.setItem(storageKey, "complete");
    setOpen(false);
  }

  function nextStep() {
    const nextIndex = stepIndex + 1;
    if (nextIndex >= steps.length) {
      finishGuide();
      return;
    }
    const nextPage = steps[nextIndex]?.[0];
    if (nextPage && nextPage !== page) setPage(nextPage);
    setStepIndex(nextIndex);
  }

  const current = steps[stepIndex] || steps[0];
  if (!user?.id || !current) return null;

  return <>
    <button type="button" onClick={() => setOpen(true)} className="fixed bottom-4 right-4 z-[90] rounded-full bg-indigo-700 px-4 py-3 text-sm font-bold text-white shadow-lg hover:bg-indigo-800" aria-label="Open DONO Guide">Guide</button>
    {open && <div className="fixed inset-0 z-[200] flex items-start justify-center overflow-y-auto bg-slate-950/60 p-4 sm:items-center"><section role="dialog" aria-modal="true" aria-labelledby="dono-guide-title" className="my-8 w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl"><div className="flex items-start justify-between gap-4"><div><p className="text-xs font-bold uppercase tracking-wide text-indigo-600">DONO Guide · {role.replaceAll("_", " ")}</p><h2 id="dono-guide-title" className="mt-1 text-xl font-bold text-slate-900">{current[1]}</h2></div><button type="button" onClick={closeGuide} className="text-sm font-semibold text-slate-500 underline">Close</button></div><div className="mt-5 rounded-xl bg-indigo-50 p-4 text-sm leading-6 text-indigo-950">{current[2]}</div><div className="mt-5 flex items-center justify-between text-xs text-slate-500"><span>Step {stepIndex + 1} of {steps.length}</span><div className="flex gap-1">{steps.map((_, index) => <span key={index} className={`h-2 w-6 rounded-full ${index <= stepIndex ? "bg-indigo-600" : "bg-slate-200"}`} />)}</div></div><div className="mt-6 flex flex-wrap justify-end gap-3"><button type="button" onClick={finishGuide} className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700">Finish for now</button><button type="button" onClick={nextStep} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">{stepIndex + 1 === steps.length ? "Complete guide" : "Next step"}</button></div></section></div>}
  </>;
}
