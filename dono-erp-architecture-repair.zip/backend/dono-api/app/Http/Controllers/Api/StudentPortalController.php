<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Student;
use App\Models\Result;
use App\Models\Attendance;
use App\Models\ReportCard;
use App\Models\StudentEnrollment;
use App\Models\Assignment;
use App\Services\Academic\ReportCardService;
use App\Services\CurrentContextService;
use Illuminate\Http\Request;

class StudentPortalController extends Controller
{
    public function __construct(
        protected CurrentContextService $context,
        protected ReportCardService $reportCardService
    ) {}

    public function dashboard(Request $request)
    {
        $user = $request->user();
        $schoolId = $request->attributes->get('current_school_id') ?? $this->context->currentSchool($user)?->id;

        $student = Student::where('user_id', $user->id)
            ->when($schoolId, fn($q) => $q->where('school_id', $schoolId))
            ->with(['class', 'stream', 'enrollments'])
            ->first();

        if (!$student) {
            // Fallback for demo or unlinked accounts
            return response()->json([
                'student_profile' => ['first_name' => $user->name, 'last_name' => '', 'admission_number' => 'UNLINKED'],
                'upcoming_assignments' => [],
                'recent_results' => [],
                'attendance_summary' => ['present' => 0, 'absent' => 0]
            ]);
        }

        $enrollmentIds = $student->enrollments()->pluck('id');

        $recentResults = Result::whereIn('student_enrollment_id', $enrollmentIds)
            ->where('is_published', true)
            ->with('subject')
            ->latest('published_at')
            ->take(5)
            ->get()
            ->map(fn($r) => [
                'subject' => $r->subject?->name ?? 'Subject',
                'score' => $r->total_score,
                'grade' => $r->grade ?? '-'
            ]);

        $presentCount = Attendance::whereIn('student_enrollment_id', $enrollmentIds)
            ->where('status', 'Present')
            ->count();
        $absentCount = Attendance::whereIn('student_enrollment_id', $enrollmentIds)
            ->where('status', 'Absent')
            ->count();

        $classIds = $student->enrollments()->pluck('class_id')->push($student->class_id)->filter()->unique();
        $upcomingAssignments = Assignment::where('school_id', $student->school_id)
            ->whereIn('class_id', $classIds)
            ->where('status', 'Published')
            ->with(['class', 'subject'])
            ->latest('due_date')
            ->take(10)
            ->get()
            ->map(fn ($assignment) => [
                'id' => $assignment->id,
                'title' => $assignment->title,
                'subject' => $assignment->subject?->name,
                'class' => $assignment->class?->name,
                'due_date' => $assignment->due_date?->toDateString(),
            ]);

        return response()->json([
            'student_profile' => $student,
            'upcoming_assignments' => $upcomingAssignments,
            'recent_results' => $recentResults,
            'attendance_summary' => [
                'present' => $presentCount,
                'absent' => $absentCount
            ]
        ]);
    }

    public function downloadLatestReportCard(Request $request)
    {
        $schoolId = $request->attributes->get('current_school_id') ?? $this->context->currentSchool($request->user())?->id;
        $student = Student::where('user_id', $request->user()->id)
            ->when($schoolId, fn ($query) => $query->where('school_id', $schoolId))
            ->first();

        abort_unless($student, 404, 'Student profile is not linked to this account.');

        $reportCard = ReportCard::where('school_id', $student->school_id)
            ->whereHas('studentEnrollment', fn ($query) => $query->where('student_id', $student->id))
            ->where('is_published', true)
            ->latest()
            ->first();

        abort_unless($reportCard, 404, 'No published report card is available yet.');

        return $this->reportCardService->downloadPdf(
            $reportCard->studentEnrollment,
            $reportCard->academic_session_id,
            $reportCard->term_id
        );
    }
}
