<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CbtQuestion;
use App\Models\Examination;
use App\Services\ActivityLogService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CbtQuestionController extends Controller
{
    public function index(Request $request)
    {
        $schoolId = $this->requireSchool($request);

        $query = CbtQuestion::where('school_id', $schoolId)
            ->with(['examination:id,name', 'creator:id,name'])
            ->when($request->filled('examination_id'), fn ($query) => $query->where('examination_id', $request->integer('examination_id')))
            ->latest();

        return response()->json($query->paginate(min(max($request->integer('per_page', 25), 1), 100)));
    }

    public function store(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        $data = $request->validate([
            'examination_id' => ['nullable', 'integer', 'exists:examinations,id'],
            'question' => ['required', 'string', 'max:10000'],
            'options' => ['required', 'array', 'min:2', 'max:8'],
            'options.*' => ['required', 'string', 'max:500'],
            'correct_answer' => ['required', 'string', 'max:255'],
            'marks' => ['sometimes', 'integer', 'min:1', 'max:100'],
            'is_active' => ['sometimes', 'boolean'],
        ]);

        if (!empty($data['examination_id'])) {
            abort_unless(Examination::whereKey($data['examination_id'])->where('school_id', $schoolId)->exists(), 422, 'The selected examination does not belong to the active school.');
        }

        abort_unless(in_array($data['correct_answer'], $data['options'], true), 422, 'The correct answer must match one of the supplied options.');

        $question = CbtQuestion::create([
            ...$data,
            'school_id' => $schoolId,
            'created_by' => $request->user()->id,
        ]);

        ActivityLogService::log(
            module: 'cbt',
            action: 'question_created',
            description: 'A CBT question was added to the school question bank.',
            subject: $question,
            schoolId: $schoolId,
        );

        return response()->json(['data' => $question->load(['examination:id,name', 'creator:id,name'])], 201);
    }

    public function update(Request $request, CbtQuestion $cbtQuestion)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $cbtQuestion->school_id === $schoolId, 404);

        $data = $request->validate([
            'examination_id' => ['nullable', 'integer', 'exists:examinations,id'],
            'question' => ['sometimes', 'required', 'string', 'max:10000'],
            'options' => ['sometimes', 'required', 'array', 'min:2', 'max:8'],
            'options.*' => ['required', 'string', 'max:500'],
            'correct_answer' => ['sometimes', 'required', 'string', 'max:255'],
            'marks' => ['sometimes', 'integer', 'min:1', 'max:100'],
            'is_active' => ['sometimes', 'boolean'],
        ]);

        $options = $data['options'] ?? $cbtQuestion->options;
        $correct = $data['correct_answer'] ?? $cbtQuestion->correct_answer;
        abort_unless(in_array($correct, $options, true), 422, 'The correct answer must match one of the supplied options.');

        if (!empty($data['examination_id'])) {
            abort_unless(Examination::whereKey($data['examination_id'])->where('school_id', $schoolId)->exists(), 422, 'The selected examination does not belong to the active school.');
        }

        $cbtQuestion->update($data);
        ActivityLogService::log(module: 'cbt', action: 'question_updated', description: 'A CBT question was updated.', subject: $cbtQuestion, schoolId: $schoolId);

        return response()->json(['data' => $cbtQuestion->fresh()->load(['examination:id,name', 'creator:id,name'])]);
    }

    public function review(Request $request, CbtQuestion $cbtQuestion)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $cbtQuestion->school_id === $schoolId, 404);
        abort_unless($this->isQuestionReviewer($request, $schoolId), 403, 'Only academic leadership can approve CBT questions.');
        $data = $request->validate([
            'approval_status' => ['required', 'in:approved,rejected,draft'],
            'review_note' => ['nullable', 'string', 'max:1000'],
        ]);
        $cbtQuestion->update([
            'approval_status' => $data['approval_status'],
            'reviewed_by' => $request->user()->id,
            'reviewed_at' => now(),
            'review_note' => $data['review_note'] ?? null,
        ]);
        ActivityLogService::log(module: 'cbt', action: 'question_reviewed', description: 'A CBT question approval state was changed.', subject: $cbtQuestion, schoolId: $schoolId, properties: ['approval_status' => $data['approval_status']]);
        return response()->json(['data' => $cbtQuestion->fresh()->load(['examination:id,name', 'creator:id,name']), 'message' => 'Question review state saved.']);
    }

    public function destroy(Request $request, CbtQuestion $cbtQuestion)
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $cbtQuestion->school_id === $schoolId, 404);
        $cbtQuestion->delete();

        ActivityLogService::log(module: 'cbt', action: 'question_deleted', description: 'A CBT question was deleted.', schoolId: $schoolId, properties: ['question_id' => $cbtQuestion->id]);

        return response()->json(['message' => 'CBT question deleted successfully.']);
    }

    private function isQuestionReviewer(Request $request, int $schoolId): bool
    {
        return collect(['proprietor', 'principal', 'vice_principal_academic', 'primary_headmaster', 'secondary_principal'])
            ->contains(fn (string $role) => $request->user()->hasRole($role, $schoolId));
    }

    public function studentQuestions(Request $request)
    {
        $schoolId = $this->requireSchool($request);

        $questions = CbtQuestion::where('school_id', $schoolId)
            ->where('is_active', true)
            ->where('approval_status', 'approved')
            ->when($request->filled('examination_id'), fn ($query) => $query->where('examination_id', $request->integer('examination_id')))
            ->get(['id', 'examination_id', 'question', 'options', 'marks']);

        return response()->json(['data' => $questions]);
    }
}
