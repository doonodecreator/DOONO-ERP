<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Assignment;
use App\Models\ClassModel;
use App\Models\Staff;
use App\Models\Student;
use App\Models\Subject;
use App\Services\CurrentContextService;
use Illuminate\Http\Request;

class AssignmentController extends Controller
{
    public function __construct(protected CurrentContextService $context) {}

    public function index(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        $query = Assignment::where('school_id', $schoolId)
            ->with(['teacher', 'class', 'stream', 'subject'])
            ->when($request->filled('class_id'), fn ($q) => $q->where('class_id', $request->integer('class_id')))
            ->when($request->filled('status'), fn ($q) => $q->where('status', $request->input('status')))
            ->latest('due_date')->latest();

        return response()->json($query->paginate(min(max($request->integer('per_page', 20), 1), 100)));
    }

    public function store(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        $data = $request->validate([
            'class_id' => ['required', 'exists:classes,id'],
            'stream_id' => ['nullable', 'exists:streams,id'],
            'subject_id' => ['required', 'exists:subjects,id'],
            'title' => ['required', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'due_date' => ['nullable', 'date'],
            'status' => ['required', 'in:Draft,Published,Closed'],
        ]);

        $this->assertAcademicOwnership($schoolId, $data);
        $staff = Staff::where('school_id', $schoolId)->where('user_id', $request->user()->id)->first();
        $assignment = Assignment::create([...$data, 'school_id' => $schoolId, 'teacher_staff_id' => $staff?->id, 'created_by' => $request->user()->id]);
        return response()->json(['data' => $assignment->load(['teacher', 'class', 'stream', 'subject'])], 201);
    }

    public function update(Request $request, Assignment $assignment)
    {
        $schoolId = $this->ensureSchool($request, $assignment);
        $data = $request->validate([
            'class_id' => ['sometimes', 'exists:classes,id'],
            'stream_id' => ['nullable', 'exists:streams,id'],
            'subject_id' => ['sometimes', 'exists:subjects,id'],
            'title' => ['sometimes', 'string', 'max:255'],
            'description' => ['nullable', 'string'],
            'due_date' => ['nullable', 'date'],
            'status' => ['sometimes', 'in:Draft,Published,Closed'],
        ]);
        $this->assertAcademicOwnership($schoolId, $data);
        $assignment->update($data);
        return response()->json(['data' => $assignment->fresh()->load(['teacher', 'class', 'stream', 'subject'])]);
    }

    public function destroy(Request $request, Assignment $assignment)
    {
        $this->ensureSchool($request, $assignment);
        $assignment->delete();
        return response()->json(['message' => 'Assignment deleted.']);
    }

    public function studentAssignments(Request $request)
    {
        $schoolId = $this->requireSchool($request);
        $student = Student::where('school_id', $schoolId)->where('user_id', $request->user()->id)->firstOrFail();
        $classIds = $student->enrollments()->pluck('class_id')->push($student->class_id)->filter()->unique();
        return response()->json(['data' => Assignment::where('school_id', $schoolId)->whereIn('class_id', $classIds)->where('status', 'Published')->with(['class', 'stream', 'subject'])->latest('due_date')->get()]);
    }

    private function assertAcademicOwnership(int $schoolId, array $data): void
    {
        abort_unless(ClassModel::whereKey($data['class_id'] ?? 0)->whereHas('division', fn ($q) => $q->where('school_id', $schoolId))->exists(), 403, 'The selected class does not belong to this school.');
        if (!empty($data['subject_id'])) abort_unless(Subject::whereKey($data['subject_id'])->where('school_id', $schoolId)->exists(), 403, 'The selected subject does not belong to this school.');
    }


    private function ensureSchool(Request $request, Assignment $assignment): int
    {
        $schoolId = $this->requireSchool($request);
        abort_unless((int) $assignment->school_id === $schoolId, 403);
        return $schoolId;
    }
}
