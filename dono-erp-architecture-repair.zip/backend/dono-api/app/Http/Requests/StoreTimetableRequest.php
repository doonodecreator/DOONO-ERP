<?php

namespace App\Http\Requests;

use App\Services\CurrentContextService;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreTimetableRequest extends FormRequest
{
    /**
     * Determine if the user is authorized.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Validation rules.
     */
    public function rules(): array
    {
        $schoolId = $this->user()
            ? app(CurrentContextService::class)->currentSchool($this->user())?->id
            : null;

        $schoolScoped = fn (string $table) => Rule::exists($table, 'id')->where(fn ($query) => $query->where('school_id', $schoolId));

        return [
            'academic_session_id' => ['required', $schoolScoped('academic_sessions')],
            'term_id' => ['required', $schoolScoped('terms')],
            'division_id' => ['required', $schoolScoped('divisions')],
            'class_id' => ['required', $schoolScoped('classes')],
            'stream_id' => ['nullable', $schoolScoped('streams')],
            'subject_id' => ['required', $schoolScoped('subjects')],
            'staff_id' => ['nullable', $schoolScoped('staff')],

            'day_of_week' => 'required|in:Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday',

            'start_time' => 'required|date_format:H:i',

            'end_time' => 'required|date_format:H:i|after:start_time',

            'room' => 'nullable|string|max:100',

            'is_active' => 'sometimes|boolean',
        ];
    }

    /**
     * Custom validation messages.
     */
    public function messages(): array
    {
        return [
            'school_id.exists' => 'Selected school does not exist.',
            'academic_session_id.exists' => 'Selected academic session does not exist.',
            'term_id.exists' => 'Selected term does not exist.',
            'division_id.exists' => 'Selected division does not exist.',
            'class_id.exists' => 'Selected class does not exist.',
            'stream_id.exists' => 'Selected stream does not exist.',
            'subject_id.exists' => 'Selected subject does not exist.',
            'staff_id.exists' => 'Selected staff member does not exist.',
            'end_time.after' => 'End time must be after start time.',
        ];
    }
}
