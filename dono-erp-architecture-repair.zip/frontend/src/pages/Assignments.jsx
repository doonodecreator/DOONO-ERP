import { useEffect, useState } from "react";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";
import { arrayFromResponse } from "../utils/response";
import PageContainer from "../components/layout/PageContainer";
import PageHeader from "../components/layout/PageHeader";
import LoadingSpinner from "../components/feedback/LoadingSpinner";
import EmptyState from "../components/feedback/EmptyState";

const initialForm = { class_id: "", stream_id: "", subject_id: "", title: "", description: "", due_date: "", status: "Draft" };

export default function Assignments() {
  const { permissions = [] } = useAuth();
  const canManage = permissions.includes("manage_assignments");
  const [assignments, setAssignments] = useState([]);
  const [classes, setClasses] = useState([]);
  const [subjects, setSubjects] = useState([]);
  const [form, setForm] = useState(initialForm);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const loadData = async () => {
    setLoading(true);
    setError("");
    try {
      const [assignmentResponse, classResponse, subjectResponse] = await Promise.all([
        api.get("/assignments"),
        api.get("/classes"),
        api.get("/subjects"),
      ]);
      setAssignments(arrayFromResponse(assignmentResponse));
      setClasses(arrayFromResponse(classResponse));
      setSubjects(arrayFromResponse(subjectResponse));
    } catch (requestError) {
      setAssignments([]);
      setError(requestError?.response?.data?.message || "Unable to load assignments.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const updateForm = (event) => setForm((current) => ({ ...current, [event.target.name]: event.target.value }));

  const saveAssignment = async (event) => {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      await api.post("/assignments", { ...form, class_id: Number(form.class_id), subject_id: Number(form.subject_id), stream_id: form.stream_id ? Number(form.stream_id) : null });
      setForm(initialForm);
      setShowForm(false);
      await loadData();
    } catch (requestError) {
      setError(requestError?.response?.data?.message || "Unable to save assignment.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <PageContainer>
      <PageHeader title="Assignments" subtitle={canManage ? "Create and publish class assignments." : "View school assignments."} action={canManage ? <button type="button" onClick={() => setShowForm((current) => !current)} className="btn-primary">{showForm ? "Close" : "New Assignment"}</button> : null} />
      {error && <div role="alert" className="mb-5 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700">{error}</div>}
      {showForm && canManage && <form onSubmit={saveAssignment} className="mb-6 grid grid-cols-1 gap-4 rounded-2xl border border-slate-200 bg-white p-5 shadow-sm md:grid-cols-2">
        <input required name="title" value={form.title} onChange={updateForm} placeholder="Assignment title" className="rounded-lg border border-slate-300 px-3 py-2 text-sm md:col-span-2" />
        <select required name="class_id" value={form.class_id} onChange={updateForm} className="rounded-lg border border-slate-300 px-3 py-2 text-sm"><option value="">Select class</option>{classes.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
        <select required name="subject_id" value={form.subject_id} onChange={updateForm} className="rounded-lg border border-slate-300 px-3 py-2 text-sm"><option value="">Select subject</option>{subjects.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
        <input type="date" name="due_date" value={form.due_date} onChange={updateForm} className="rounded-lg border border-slate-300 px-3 py-2 text-sm" />
        <select name="status" value={form.status} onChange={updateForm} className="rounded-lg border border-slate-300 px-3 py-2 text-sm"><option value="Draft">Draft</option><option value="Published">Published</option><option value="Closed">Closed</option></select>
        <textarea name="description" value={form.description} onChange={updateForm} placeholder="Instructions" className="min-h-24 rounded-lg border border-slate-300 px-3 py-2 text-sm md:col-span-2" />
        <button disabled={saving} type="submit" className="btn-primary md:col-span-2">{saving ? "Saving..." : "Save Assignment"}</button>
      </form>}
      {loading ? <LoadingSpinner text="Loading assignments..." /> : assignments.length === 0 ? <EmptyState title="No assignments found" message="Published or created assignments will appear here." /> : <div className="grid grid-cols-1 gap-4 md:grid-cols-2">{assignments.map((assignment) => <article key={assignment.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-start justify-between gap-3"><h2 className="font-bold text-slate-900">{assignment.title}</h2><span className="rounded-full bg-indigo-50 px-2 py-1 text-xs font-semibold text-indigo-700">{assignment.status}</span></div><p className="mt-2 text-sm text-slate-600">{assignment.subject?.name || "Subject"} · {assignment.class?.name || "Class"}</p><p className="mt-2 text-sm text-slate-500">{assignment.description || "No additional instructions."}</p>{assignment.due_date && <p className="mt-4 text-xs font-semibold text-slate-500">Due {assignment.due_date}</p>}</article>)}</div>}
    </PageContainer>
  );
}
