import React, { useEffect, useMemo, useState } from "react";
import api from "../services/api";
import LoadingSpinner from "../components/feedback/LoadingSpinner";
import { useAuth } from "../context/AuthContext";
import { getPrimaryRoleSlug } from "../utils/role";
import { arrayFromResponse } from "../utils/response";

const emptyStructure = {
    name: "",
    amount: "",
    category: "Tuition",
    academic_session_id: "",
    term_id: "",
    division_id: "",
    class_id: "",
    description: "",
    is_active: true,
};

const errorMessage = (reason, fallback) => reason?.response?.data?.message || reason?.message || fallback;

export default function FeesAndPayments() {
    const { roles, isPlatformAdmin, isOrganizationOwner, school, permissions } = useAuth();
    const role = getPrimaryRoleSlug({ roles, isPlatformAdmin, isOrganizationOwner, school });
    const canManageFees = role === "proprietor" && permissions.includes("manage_fee_categories");
    const [activeTab, setActiveTab] = useState("structures");
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [configError, setConfigError] = useState("");
    const [paymentsError, setPaymentsError] = useState("");
    const [formError, setFormError] = useState("");
    const [structures, setStructures] = useState([]);
    const [payments, setPayments] = useState([]);
    const [sessions, setSessions] = useState([]);
    const [terms, setTerms] = useState([]);
    const [divisions, setDivisions] = useState([]);
    const [classes, setClasses] = useState([]);
    const [showStructureModal, setShowStructureModal] = useState(false);
    const [structureForm, setStructureForm] = useState(emptyStructure);

    const visibleTerms = useMemo(
        () => terms.filter((term) => !structureForm.academic_session_id || String(term.academic_session_id) === String(structureForm.academic_session_id)),
        [terms, structureForm.academic_session_id]
    );
    const visibleClasses = useMemo(
        () => classes.filter((item) => !structureForm.division_id || String(item.division_id) === String(structureForm.division_id)),
        [classes, structureForm.division_id]
    );

    const loadData = async () => {
        setLoading(true);
        setConfigError("");
        setPaymentsError("");
        const requests = [
            ["fee structures", api.get("/fees")],
            ["academic sessions", api.get("/academic-sessions")],
            ["terms", api.get("/terms")],
            ["divisions", api.get("/divisions")],
            ["classes", api.get("/classes")],
            ["payment history", api.get("/fee-payments")],
        ];
        const results = await Promise.all(requests.map(async ([label, request]) => {
            try {
                return { label, status: "fulfilled", value: await request };
            } catch (reason) {
                return { label, status: "rejected", reason };
            }
        }));

        const get = (label) => results.find((item) => item.label === label);
        const configResults = results.filter((item) => ["fee structures", "academic sessions", "terms", "divisions", "classes"].includes(item.label));
        const failedConfig = configResults.filter((item) => item.status === "rejected");
        const failedPayments = get("payment history")?.status === "rejected";

        const feeStructures = get("fee structures");
        const academicSessions = get("academic sessions");
        const academicTerms = get("terms");
        const academicDivisions = get("divisions");
        const academicClasses = get("classes");

        if (feeStructures?.status === "fulfilled") setStructures(arrayFromResponse(feeStructures.value));
        if (academicSessions?.status === "fulfilled") setSessions(arrayFromResponse(academicSessions.value));
        if (academicTerms?.status === "fulfilled") setTerms(arrayFromResponse(academicTerms.value));
        if (academicDivisions?.status === "fulfilled") setDivisions(arrayFromResponse(academicDivisions.value));
        if (academicClasses?.status === "fulfilled") setClasses(arrayFromResponse(academicClasses.value));
        if (get("payment history")?.status === "fulfilled") setPayments(arrayFromResponse(get("payment history").value));

        if (failedConfig.length > 0) {
            setConfigError(failedConfig.map((item) => `${item.label}: ${errorMessage(item.reason, "request failed")}`).join(" "));
        }
        if (failedPayments) {
            setPaymentsError(errorMessage(get("payment history").reason, "Payment history could not be loaded."));
        }
        setLoading(false);
    };

    useEffect(() => { loadData(); }, []);

    const updateForm = (name, value) => {
        setStructureForm((current) => {
            const next = { ...current, [name]: value };
            if (name === "academic_session_id") next.term_id = "";
            if (name === "division_id") next.class_id = "";
            return next;
        });
    };

    const handleCreateStructure = async (event) => {
        event.preventDefault();
        setSaving(true);
        setFormError("");
        try {
            await api.post("/fees", structureForm);
            setShowStructureModal(false);
            setStructureForm(emptyStructure);
            await loadData();
        } catch (err) {
            const errors = err.response?.data?.errors;
            setFormError(errors ? Object.values(errors).flat().join(" ") : errorMessage(err, "Failed to save fee structure."));
        } finally {
            setSaving(false);
        }
    };

    const handleDeleteStructure = async (id, name) => {
        if (!window.confirm(`Are you sure you want to delete fee structure "${name}"?`)) return;
        try {
            await api.delete(`/fees/${id}`);
            await loadData();
        } catch (err) {
            setConfigError(errorMessage(err, "Failed to delete fee structure."));
        }
    };

    if (loading) return <LoadingSpinner text="Loading fee configuration..." />;

    return (
        <div className="min-h-screen bg-gray-50 p-4 md:p-6">
            <div className="mb-6 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                <div><h1 className="text-2xl font-bold text-gray-800">Fee Structures & Payment History</h1><p className="text-sm text-gray-500">Define academic fee rates and inspect payment receipt records.</p></div>
                {canManageFees && activeTab === "structures" && <button type="button" onClick={() => { setFormError(""); setShowStructureModal(true); }} className="rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white shadow-sm hover:bg-blue-700">+ Create Fee Structure</button>}
            </div>

            <div className="mb-6 flex rounded-xl bg-white p-1 shadow-sm">
                <button type="button" onClick={() => setActiveTab("structures")} className={`flex-1 rounded-lg py-2.5 text-sm font-semibold ${activeTab === "structures" ? "bg-blue-600 text-white" : "text-gray-600"}`}>Fee Structures ({structures.length})</button>
                <button type="button" onClick={() => setActiveTab("payments")} className={`flex-1 rounded-lg py-2.5 text-sm font-semibold ${activeTab === "payments" ? "bg-blue-600 text-white" : "text-gray-600"}`}>Payment Logs ({payments.length})</button>
            </div>

            {activeTab === "structures" && configError && <div className="mb-6 flex items-start justify-between gap-3 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700"><span>{configError}</span><button type="button" onClick={loadData} className="shrink-0 font-semibold underline">Retry</button></div>}
            {activeTab === "payments" && paymentsError && <div className="mb-6 flex items-start justify-between gap-3 rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700"><span>{paymentsError}</span><button type="button" onClick={loadData} className="shrink-0 font-semibold underline">Retry</button></div>}

            {activeTab === "structures" ? (
                <div className="overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm">
                    {configError ? <div className="p-12 text-center text-gray-500">Fee configuration could not be loaded. Correct the error above and retry.</div> : structures.length === 0 ? <div className="p-12 text-center text-gray-400">No fee structures configured yet.</div> : <div className="overflow-x-auto"><table className="w-full text-left text-sm text-gray-600"><thead className="border-b border-gray-100 bg-gray-50 text-gray-500"><tr><th className="px-6 py-3">Fee Name</th><th className="px-6 py-3">Category</th><th className="px-6 py-3">Session / Term</th><th className="px-6 py-3">Class</th><th className="px-6 py-3">Amount</th><th className="px-6 py-3 text-right">Actions</th></tr></thead><tbody className="divide-y divide-gray-100">{structures.map((item) => <tr key={item.id}><td className="px-6 py-4 font-medium text-gray-900">{item.name}</td><td className="px-6 py-4">{item.category || "Tuition"}</td><td className="px-6 py-4">{item.academic_session?.name || "—"} / {item.term?.name || "—"}</td><td className="px-6 py-4">{item.class?.name || "All Classes"}</td><td className="px-6 py-4 font-mono font-semibold">₦{Number(item.amount || 0).toLocaleString()}</td><td className="px-6 py-4 text-right">{canManageFees && <button type="button" onClick={() => handleDeleteStructure(item.id, item.name)} className="text-xs font-medium text-red-600 hover:text-red-800">Delete</button>}</td></tr>)}</tbody></table></div>}
                </div>
            ) : (
                <div className="overflow-hidden rounded-xl border border-gray-100 bg-white shadow-sm">
                    {paymentsError ? <div className="p-12 text-center text-gray-500">Payment history could not be loaded. Fee configuration remains available on the other tab.</div> : payments.length === 0 ? <div className="p-12 text-center text-gray-400">No payment receipts logged yet.</div> : <div className="overflow-x-auto"><table className="w-full text-left text-sm text-gray-600"><thead className="border-b border-gray-100 bg-gray-50 text-gray-500"><tr><th className="px-6 py-3">Receipt No</th><th className="px-6 py-3">Amount Paid</th><th className="px-6 py-3">Payment Method</th><th className="px-6 py-3">Date</th><th className="px-6 py-3">Ref</th></tr></thead><tbody className="divide-y divide-gray-100">{payments.map((item) => <tr key={item.id}><td className="px-6 py-4 font-mono font-semibold">{item.receipt_number || `REC-${item.id}`}</td><td className="px-6 py-4 font-mono font-semibold text-green-700">₦{Number(item.amount_paid || 0).toLocaleString()}</td><td className="px-6 py-4">{item.payment_method || "Cash"}</td><td className="px-6 py-4">{item.payment_date || "—"}</td><td className="px-6 py-4 font-mono text-xs">{item.transaction_reference || "—"}</td></tr>)}</tbody></table></div>}
                </div>
            )}

            {showStructureModal && canManageFees && <div className="fixed inset-0 z-50 overflow-y-auto bg-black/40 p-3 sm:p-6"><div className="flex min-h-full items-start justify-center"><div className="my-0 max-h-[calc(100dvh-1.5rem)] w-full max-w-lg overflow-y-auto rounded-xl bg-white shadow-xl sm:my-4 sm:max-h-[calc(100dvh-3rem)]"><div className="sticky top-0 z-10 flex items-center justify-between border-b bg-white px-4 py-4 sm:px-6"><h2 className="text-lg font-bold text-gray-800">Create Fee Structure</h2><button type="button" onClick={() => setShowStructureModal(false)} className="rounded-lg px-3 py-1 text-2xl text-gray-500">×</button></div><form onSubmit={handleCreateStructure} className="space-y-4 p-4 sm:p-6">{formError && <div className="rounded-lg bg-red-50 p-3 text-sm text-red-700">{formError}</div>}<div><label className="mb-1 block text-xs font-semibold text-gray-600">Fee Name *</label><input type="text" placeholder="e.g. 1st Term Tuition Fee" value={structureForm.name} onChange={(event) => updateForm("name", event.target.value)} required className="w-full rounded-lg border px-3 py-3 text-sm" /></div><div className="grid grid-cols-1 gap-4 sm:grid-cols-2"><div><label className="mb-1 block text-xs font-semibold text-gray-600">Amount (₦) *</label><input type="number" min="0" step="0.01" placeholder="0.00" value={structureForm.amount} onChange={(event) => updateForm("amount", event.target.value)} required className="w-full rounded-lg border px-3 py-3 text-sm" /></div><div><label className="mb-1 block text-xs font-semibold text-gray-600">Category *</label><select value={structureForm.category} onChange={(event) => updateForm("category", event.target.value)} className="w-full rounded-lg border bg-white px-3 py-3 text-sm"><option>Tuition</option><option>Admission</option><option>Uniform</option><option>Books</option><option>Exam</option><option>Transport</option></select></div></div><div><label className="mb-1 block text-xs font-semibold text-gray-600">Academic Session *</label><select required value={structureForm.academic_session_id} onChange={(event) => updateForm("academic_session_id", event.target.value)} className="w-full rounded-lg border bg-white px-3 py-3 text-sm"><option value="">Select session</option>{sessions.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div><div><label className="mb-1 block text-xs font-semibold text-gray-600">Term *</label><select required value={structureForm.term_id} onChange={(event) => updateForm("term_id", event.target.value)} className="w-full rounded-lg border bg-white px-3 py-3 text-sm"><option value="">Select term</option>{visibleTerms.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div><div><label className="mb-1 block text-xs font-semibold text-gray-600">Division *</label><select required value={structureForm.division_id} onChange={(event) => updateForm("division_id", event.target.value)} className="w-full rounded-lg border bg-white px-3 py-3 text-sm"><option value="">Select division</option>{divisions.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div><div><label className="mb-1 block text-xs font-semibold text-gray-600">Class *</label><select required value={structureForm.class_id} onChange={(event) => updateForm("class_id", event.target.value)} className="w-full rounded-lg border bg-white px-3 py-3 text-sm"><option value="">Select class</option>{visibleClasses.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></div><div><label className="mb-1 block text-xs font-semibold text-gray-600">Description</label><textarea value={structureForm.description} onChange={(event) => updateForm("description", event.target.value)} rows="3" className="w-full rounded-lg border px-3 py-3 text-sm" /></div><label className="flex min-h-11 items-center gap-3 text-sm"><input type="checkbox" checked={structureForm.is_active} onChange={(event) => updateForm("is_active", event.target.checked)} className="h-5 w-5" /> Active fee structure</label><div className="sticky bottom-0 -mx-4 flex gap-3 border-t bg-white px-4 pb-1 pt-4 sm:-mx-6 sm:px-6"><button type="button" onClick={() => setShowStructureModal(false)} className="flex-1 rounded-lg border px-4 py-3 text-sm font-semibold text-gray-600">Cancel</button><button type="submit" disabled={saving} className="flex-1 rounded-lg bg-blue-600 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50">{saving ? "Saving..." : "Save Fee Structure"}</button></div></form></div></div></div>}
        </div>
    );
}
