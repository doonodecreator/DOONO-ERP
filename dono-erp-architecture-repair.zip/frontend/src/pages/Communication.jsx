import { useEffect, useMemo, useState } from "react";
import api from "../services/api";
import { useAuth } from "../context/AuthContext";
import { getPrimaryRoleSlug } from "../utils/role";
import PageContainer from "../components/layout/PageContainer";
import PageHeader from "../components/layout/PageHeader";
import LoadingSpinner from "../components/feedback/LoadingSpinner";
import EmptyState from "../components/feedback/EmptyState";

const emptyForm = {
  type: "notice",
  audience: "all",
  recipient_id: "",
  subject: "",
  body: "",
  is_published: true,
};

const toItems = (response) => {
  const value = response?.data?.data ?? response?.data ?? response ?? [];
  if (Array.isArray(value)) return value;
  if (Array.isArray(value?.data)) return value.data;
  return [];
};

export default function Communication({ mode = "all" }) {
  const { roles, isPlatformAdmin, isOrganizationOwner, school } = useAuth();
  const role = getPrimaryRoleSlug({ roles, isPlatformAdmin, isOrganizationOwner, school });
  const canSend = ["proprietor", "principal", "vice_principal_academic", "vice_principal_admin", "teacher", "form_teacher", "nursery_head", "primary_headmaster", "secondary_principal", "receptionist"].includes(role);
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const title = mode === "notices" ? "School Notices" : mode === "messages" ? "Messages & Chat" : "Communication";
  const typeFilter = mode === "notices" ? "notice" : mode === "messages" ? "message" : "";

  async function load() {
    try {
      setLoading(true);
      setError("");
      const response = await api.get("/communications", { params: typeFilter ? { type: typeFilter, per_page: 50 } : { per_page: 50 } });
      setItems(toItems(response));
    } catch (err) {
      setItems([]);
      setError(err.response?.data?.message || "Unable to load communication records.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, [typeFilter]);

  const visibleItems = useMemo(() => (Array.isArray(items) ? items : []), [items]);

  async function submit(event) {
    event.preventDefault();
    try {
      setSaving(true);
      setError("");
      setMessage("");
      await api.post("/communications", {
        ...form,
        recipient_id: form.recipient_id ? Number(form.recipient_id) : null,
        is_published: Boolean(form.is_published),
      });
      setForm(emptyForm);
      setShowForm(false);
      setMessage("Communication published successfully.");
      await load();
    } catch (err) {
      const errors = err.response?.data?.errors;
      const first = errors ? Object.values(errors)?.[0]?.[0] : null;
      setError(first || err.response?.data?.message || "Unable to publish communication.");
    } finally {
      setSaving(false);
    }
  }

  async function markRead(item) {
    if (!item?.id || item.read_at) return;
    try {
      await api.post(`/communications/${item.id}/read`);
      setItems((current) => current.map((entry) => entry.id === item.id ? { ...entry, read_at: new Date().toISOString() } : entry));
    } catch {
      // Reading is best effort; the message remains visible if the write is denied.
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title={title}
        subtitle="School-scoped notices and messages for the right audience."
        action={canSend ? <button type="button" onClick={() => setShowForm((value) => !value)} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white">{showForm ? "Close" : "New communication"}</button> : null}
      />

      {error && <div role="alert" className="mb-5 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error} <button type="button" onClick={load} className="ml-2 font-semibold underline">Retry</button></div>}
      {message && <div role="status" className="mb-5 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-700">{message}</div>}

      {showForm && canSend && (
        <form onSubmit={submit} className="mb-6 space-y-4 rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
          <div className="grid gap-4 sm:grid-cols-3">
            <label className="text-sm font-semibold text-slate-700">Type<select value={form.type} onChange={(event) => setForm({ ...form, type: event.target.value })} className="mt-1 w-full rounded-lg border p-2 font-normal"><option value="notice">Notice</option><option value="message">Message</option></select></label>
            <label className="text-sm font-semibold text-slate-700">Audience<select value={form.audience} onChange={(event) => setForm({ ...form, audience: event.target.value })} className="mt-1 w-full rounded-lg border p-2 font-normal"><option value="all">Everyone</option><option value="staff">Staff</option><option value="parents">Parents</option><option value="students">Students</option><option value="individual">Individual user</option></select></label>
            {form.audience === "individual" && <label className="text-sm font-semibold text-slate-700">Recipient user ID<input required value={form.recipient_id} onChange={(event) => setForm({ ...form, recipient_id: event.target.value })} className="mt-1 w-full rounded-lg border p-2 font-normal" inputMode="numeric" /></label>}
          </div>
          <label className="block text-sm font-semibold text-slate-700">Subject<input value={form.subject} onChange={(event) => setForm({ ...form, subject: event.target.value })} className="mt-1 w-full rounded-lg border p-2 font-normal" maxLength={180} /></label>
          <label className="block text-sm font-semibold text-slate-700">Message<textarea required value={form.body} onChange={(event) => setForm({ ...form, body: event.target.value })} className="mt-1 min-h-28 w-full rounded-lg border p-2 font-normal" maxLength={10000} /></label>
          <div className="flex items-center justify-between gap-3"><label className="flex items-center gap-2 text-sm text-slate-600"><input type="checkbox" checked={form.is_published} onChange={(event) => setForm({ ...form, is_published: event.target.checked })} /> Publish now</label><button type="submit" disabled={saving} className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white disabled:opacity-60">{saving ? "Publishing..." : "Publish"}</button></div>
        </form>
      )}

      {loading ? <LoadingSpinner /> : visibleItems.length === 0 ? <EmptyState title={`No ${title.toLowerCase()} yet`} message="Published school-scoped communication will appear here." /> : <div className="space-y-3">{visibleItems.map((item) => <article key={item.id} onClick={() => markRead(item)} className={`rounded-xl border bg-white p-4 shadow-sm ${item.read_at ? "border-slate-200" : "border-indigo-200 bg-indigo-50/30"}`}><div className="flex flex-wrap items-center justify-between gap-2"><div><span className="rounded-full bg-slate-100 px-2 py-1 text-xs font-semibold uppercase text-slate-600">{item.type || "notice"}</span><span className="ml-2 text-xs text-slate-500">To: {item.audience || "all"}</span></div><time className="text-xs text-slate-500">{item.published_at ? new Date(item.published_at).toLocaleString() : "Draft"}</time></div><h2 className="mt-3 font-semibold text-slate-900">{item.subject || "School communication"}</h2><p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">{item.body}</p><p className="mt-3 text-xs text-slate-500">From: {item.sender?.name || "School staff"}</p></article>)}</div>}
    </PageContainer>
  );
}
