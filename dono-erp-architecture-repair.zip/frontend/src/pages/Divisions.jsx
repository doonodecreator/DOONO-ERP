import { useEffect, useState } from "react";
import api from "../services/api";
import PageHeader from "../components/layout/PageHeader";
import LoadingSpinner from "../components/feedback/LoadingSpinner";
import EmptyState from "../components/feedback/EmptyState";

const emptyForm = { name: "", code: "", display_order: 1, is_active: true };
const listFromResponse = (response) => {
    const value = response?.data?.data?.data ?? response?.data?.data ?? response?.data;
    return Array.isArray(value) ? value : [];
};

export default function Divisions() {
    const [divisions, setDivisions] = useState([]);
    const [form, setForm] = useState(emptyForm);
    const [editingId, setEditingId] = useState(null);
    const [showModal, setShowModal] = useState(false);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");
    const [formError, setFormError] = useState("");

    const loadDivisions = async () => {
        setLoading(true);
        setError("");
        try {
            setDivisions(listFromResponse(await api.get("/divisions")));
        } catch (err) {
            setDivisions([]);
            setError(err.response?.data?.message || "Unable to load divisions.");
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => { loadDivisions(); }, []);

    const openModal = (division = null) => {
        setEditingId(division?.id || null);
        setForm(division ? { name: division.name || "", code: division.code || "", display_order: division.display_order || 1, is_active: division.is_active ?? true } : emptyForm);
        setFormError("");
        setShowModal(true);
    };

    const handleChange = (event) => {
        const { name, value, checked, type } = event.target;
        setForm((current) => ({ ...current, [name]: type === "checkbox" ? checked : value }));
    };

    const saveDivision = async (event) => {
        event.preventDefault();
        setSubmitting(true);
        setFormError("");
        try {
            if (editingId) await api.put(`/divisions/${editingId}`, form);
            else await api.post("/divisions", form);
            setShowModal(false);
            setForm(emptyForm);
            await loadDivisions();
        } catch (err) {
            const validationErrors = err.response?.data?.errors;
            setFormError(validationErrors ? Object.values(validationErrors).flat().join(" ") : (err.response?.data?.message || "Unable to save division."));
        } finally {
            setSubmitting(false);
        }
    };

    const deleteDivision = async (division) => {
        if (!window.confirm(`Delete ${division.name}?`)) return;
        try {
            await api.delete(`/divisions/${division.id}`);
            await loadDivisions();
        } catch (err) {
            setError(err.response?.data?.message || "Unable to delete division.");
        }
    };

    return <div className="p-6">
        <PageHeader title="Divisions" subtitle="Create the broad school sections before defining classes and streams." action={<button type="button" onClick={() => openModal()} className="rounded-lg bg-indigo-600 px-4 py-2 font-semibold text-white hover:bg-indigo-700">Add Division</button>} />
        {error && <div className="mb-5 rounded-lg border border-rose-200 bg-rose-50 p-4 text-rose-700"><span>{error}</span><button type="button" onClick={loadDivisions} className="ml-4 font-semibold underline">Retry</button></div>}
        {loading ? <LoadingSpinner text="Loading divisions..." /> : divisions.length === 0 ? <EmptyState title="No divisions yet" message="Create divisions such as Nursery, Primary, or Secondary." /> : <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm"><table className="min-w-full text-left text-sm"><thead className="bg-slate-50 text-slate-600"><tr><th className="px-5 py-3">Name</th><th className="px-5 py-3">Code</th><th className="px-5 py-3">Order</th><th className="px-5 py-3">Status</th><th className="px-5 py-3 text-right">Actions</th></tr></thead><tbody className="divide-y divide-slate-100">{divisions.map((division) => <tr key={division.id}><td className="px-5 py-4 font-semibold text-slate-900">{division.name}</td><td className="px-5 py-4">{division.code || "—"}</td><td className="px-5 py-4">{division.display_order || "—"}</td><td className="px-5 py-4">{division.is_active ? "Active" : "Inactive"}</td><td className="px-5 py-4 text-right"><button type="button" onClick={() => openModal(division)} className="mr-3 font-semibold text-indigo-600">Edit</button><button type="button" onClick={() => deleteDivision(division)} className="font-semibold text-rose-600">Delete</button></td></tr>)}</tbody></table></div>}
        {showModal && (
            <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/50 p-3 sm:p-6" role="dialog" aria-modal="true" aria-labelledby="division-dialog-title">
                <div className="flex min-h-full items-start justify-center">
                    <div className="my-0 w-full max-w-md overflow-y-auto rounded-2xl bg-white shadow-xl max-h-[calc(100dvh-1.5rem)] sm:my-4 sm:max-h-[calc(100dvh-3rem)]">
                        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-slate-100 bg-white px-4 py-4 sm:px-6">
                            <h2 id="division-dialog-title" className="text-xl font-bold text-slate-900">{editingId ? "Edit Division" : "Add Division"}</h2>
                            <button type="button" onClick={() => setShowModal(false)} aria-label="Close division form" className="rounded-lg px-3 py-1 text-2xl leading-none text-slate-500 hover:bg-slate-100">×</button>
                        </div>
                        <div className="p-4 sm:p-6">
                            {formError && <div className="mb-4 rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{formError}</div>}
                            <form onSubmit={saveDivision} className="space-y-4">
                                <div><label htmlFor="division-name" className="mb-1 block text-sm font-semibold text-slate-700">Division name</label><input id="division-name" required name="name" value={form.name} onChange={handleChange} placeholder="e.g. Primary" className="w-full rounded-lg border border-slate-300 px-3 py-3" /></div>
                                <div><label htmlFor="division-code" className="mb-1 block text-sm font-semibold text-slate-700">Code <span className="font-normal text-slate-400">(optional)</span></label><input id="division-code" name="code" value={form.code} onChange={handleChange} placeholder="e.g. PRI" className="w-full rounded-lg border border-slate-300 px-3 py-3" /></div>
                                <div><label htmlFor="division-order" className="mb-1 block text-sm font-semibold text-slate-700">Display order</label><input id="division-order" required min="1" type="number" name="display_order" value={form.display_order} onChange={handleChange} className="w-full rounded-lg border border-slate-300 px-3 py-3" /></div>
                                <label className="flex min-h-11 items-center gap-3 text-sm"><input type="checkbox" name="is_active" checked={form.is_active} onChange={handleChange} className="h-5 w-5" /> Active division</label>
                                <div className="sticky bottom-0 -mx-4 flex gap-3 border-t border-slate-100 bg-white px-4 pb-1 pt-4 sm:-mx-6 sm:px-6">
                                    <button type="button" onClick={() => setShowModal(false)} className="flex-1 rounded-lg border border-slate-200 px-4 py-3 text-sm font-semibold text-slate-700">Cancel</button>
                                    <button disabled={submitting} type="submit" className="flex-1 rounded-lg bg-indigo-600 px-4 py-3 text-sm font-semibold text-white disabled:opacity-50">{submitting ? "Saving..." : "Save Division"}</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        )}
    </div>;
}
